# Eclipse of Empires

## Overview

Eclipse of Empires is a medieval strategy game built with Flask that combines human and AI players in a persistent turn-based world. Players build kingdoms, manage resources (food, wood, stone, gold), construct and upgrade buildings, train armies, and compete for territorial control on a procedurally generated map. The game features a real-time tick system where AI opponents make strategic decisions based on configurable personality traits, creating a dynamic competitive environment that continues evolving even when human players are offline.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
The application follows a modular Flask-based architecture with clear separation of concerns:

- **Flask Web Framework**: Serves as the main application server handling HTTP requests and session management
- **Game Engine (game_logic.py)**: Core game logic module managing game state, map generation, and player actions
- **AI Engine (ai_logic.py)**: Dedicated AI system for computer-controlled players with personality-based decision making
- **Models (models.py)**: Data structures for game state, players, and game entities
- **Routes (routes.py)**: RESTful API endpoints for game interactions and state updates

### Game State Management
- **JSON-based Persistence**: Game state is stored in a single JSON file (game_state.json) for simplicity
- **In-memory Processing**: All game logic operates on in-memory objects for performance
- **Periodic Saving**: Game state is persisted to disk after AI turns and significant events

### Real-time Game Loop
- **APScheduler Integration**: Background scheduler manages game ticks every 30 seconds and AI turns every 60 seconds
- **Non-blocking Architecture**: Game continues running independently of user sessions
- **Session-based Player Management**: Players are identified and managed through Flask sessions

### Frontend Architecture
- **Server-side Rendered Templates**: Jinja2 templates with Bootstrap for responsive UI
- **Canvas-based Map Rendering**: HTML5 Canvas for interactive game map with tile-based visualization
- **Modular JavaScript**: Separate modules for game logic (game.js), map rendering (map.js), and UI management (ui.js)
- **AJAX Communication**: Asynchronous updates for game state without full page reloads

### AI System Design
- **Personality-driven AI**: Each AI player has configurable traits (economy, aggression, expansion) that influence decision making
- **Multi-faceted Decision Making**: AI considers economic development, military expansion, and territorial growth
- **Scalable AI Processing**: Designed to handle multiple AI players with different strategies simultaneously

## External Dependencies

### Core Framework Dependencies
- **Flask**: Web application framework for routing and session management
- **APScheduler**: Background task scheduler for game ticks and AI processing
- **Python Standard Library**: JSON handling, logging, datetime operations, and file I/O

### Frontend Dependencies
- **Bootstrap 5.3.0**: CSS framework for responsive design and UI components
- **Feather Icons**: Icon library for consistent visual elements
- **HTML5 Canvas**: For interactive map rendering and game visualization

### Development Dependencies
- **Python 3.x**: Runtime environment
- **No Database Required**: Uses file-based JSON storage for simplicity and portability

### Potential Future Integrations
The architecture is designed to easily accommodate:
- Database integration (PostgreSQL/SQLite) for improved data management
- WebSocket connections for real-time multiplayer features
- External authentication services
- Cloud storage for game state persistence
- Analytics and metrics collection services