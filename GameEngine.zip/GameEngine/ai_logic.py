import random
import logging
from typing import Dict, List, Any, Optional
from game_logic import GameEngine

class AIEngine:
    def __init__(self, game_engine: GameEngine):
        self.game_engine = game_engine
        
    def process_ai_turns(self):
        """Process AI decisions for all AI players"""
        for player_id, player_data in self.game_engine.state.players.items():
            if player_data.get('is_ai', False):
                self.process_ai_player(player_id, player_data)
        
        self.game_engine.save_game_state()
        logging.info("AI turns processed")
    
    def process_ai_player(self, player_id: str, player_data: Dict):
        """Process decisions for a single AI player"""
        personality = player_data.get('ai_personality', {})
        
        # Make decisions based on personality and current state
        decisions = self.make_decisions(player_id, player_data, personality)
        
        # Execute decisions
        for decision in decisions:
            self.execute_decision(player_id, decision)
    
    def make_decisions(self, player_id: str, player_data: Dict, personality: Dict) -> List[Dict[str, Any]]:
        """Generate list of decisions for AI player"""
        decisions = []
        
        # Analyze current situation
        resources = player_data['resources']
        buildings = player_data['buildings']
        troops = player_data['troops']
        
        # Economic decisions
        if personality.get('economy', 0.5) > 0.4:
            economic_decisions = self.get_economic_decisions(resources, buildings, personality)
            decisions.extend(economic_decisions)
        
        # Military decisions
        if personality.get('aggression', 0.5) > 0.3:
            military_decisions = self.get_military_decisions(player_id, resources, troops, buildings, personality)
            decisions.extend(military_decisions)
        
        # Expansion decisions
        if personality.get('expansion', 0.5) > 0.4:
            expansion_decisions = self.get_expansion_decisions(player_id, player_data, personality)
            decisions.extend(expansion_decisions)
        
        # Prioritize decisions
        return self.prioritize_decisions(decisions, personality)
    
    def get_economic_decisions(self, resources: Dict, buildings: Dict, personality: Dict) -> List[Dict[str, Any]]:
        """Generate economic building decisions"""
        decisions = []
        
        # Check resource levels and building levels
        food_ratio = resources['food'] / (resources['food'] + 1000)
        wood_ratio = resources['wood'] / (resources['wood'] + 1000)
        stone_ratio = resources['stone'] / (resources['stone'] + 500)
        gold_ratio = resources['gold'] / (resources['gold'] + 500)
        
        # Upgrade priorities based on resource shortages
        if food_ratio < 0.3 and not buildings['farm']['upgrading']:
            decisions.append({
                'type': 'upgrade_building',
                'building': 'farm',
                'priority': 0.8 + personality.get('economy', 0.5) * 0.2
            })
        
        if wood_ratio < 0.3 and not buildings['lumber_mill']['upgrading']:
            decisions.append({
                'type': 'upgrade_building',
                'building': 'lumber_mill',
                'priority': 0.7 + personality.get('economy', 0.5) * 0.2
            })
        
        if stone_ratio < 0.3 and not buildings['quarry']['upgrading']:
            decisions.append({
                'type': 'upgrade_building',
                'building': 'quarry',
                'priority': 0.6 + personality.get('economy', 0.5) * 0.2
            })
        
        if gold_ratio < 0.2 and not buildings['gold_mine']['upgrading']:
            decisions.append({
                'type': 'upgrade_building',
                'building': 'gold_mine',
                'priority': 0.5 + personality.get('economy', 0.5) * 0.3
            })
        
        # Always consider upgrading town hall for overall efficiency
        if (resources['wood'] > 2000 and resources['stone'] > 2000 and 
            not buildings['town_hall']['upgrading']):
            decisions.append({
                'type': 'upgrade_building',
                'building': 'town_hall',
                'priority': 0.4 + personality.get('economy', 0.5) * 0.4
            })
        
        return decisions
    
    def get_military_decisions(self, player_id: str, resources: Dict, troops: Dict, 
                             buildings: Dict, personality: Dict) -> List[Dict[str, Any]]:
        """Generate military decisions"""
        decisions = []
        
        total_troops = sum(troops.values())
        aggression = personality.get('aggression', 0.5)
        
        # Build military buildings if needed
        if buildings['barracks']['level'] == 0 and resources['wood'] > 500:
            decisions.append({
                'type': 'upgrade_building',
                'building': 'barracks',
                'priority': 0.6 + aggression * 0.3
            })
        
        if (buildings['archery_range']['level'] == 0 and 
            buildings['barracks']['level'] > 0 and resources['wood'] > 400):
            decisions.append({
                'type': 'upgrade_building',
                'building': 'archery_range',
                'priority': 0.5 + aggression * 0.3
            })
        
        # Train troops if military buildings are available
        if buildings['barracks']['level'] > 0 and resources['food'] > 200:
            troop_count = min(10, resources['food'] // 50)
            decisions.append({
                'type': 'train_troops',
                'troop_type': 'infantry',
                'quantity': troop_count,
                'priority': 0.5 + aggression * 0.4
            })
        
        if buildings['archery_range']['level'] > 0 and resources['wood'] > 300:
            troop_count = min(8, resources['wood'] // 50)
            decisions.append({
                'type': 'train_troops',
                'troop_type': 'archer',
                'quantity': troop_count,
                'priority': 0.4 + aggression * 0.3
            })
        
        # Consider attacking if army is strong enough
        if total_troops > 20 and aggression > 0.6:
            target = self.find_attack_target(player_id)
            if target:
                decisions.append({
                    'type': 'attack',
                    'target': target,
                    'priority': aggression * 0.8
                })
        
        return decisions
    
    def get_expansion_decisions(self, player_id: str, player_data: Dict, personality: Dict) -> List[Dict[str, Any]]:
        """Generate expansion decisions"""
        decisions = []
        
        expansion_drive = personality.get('expansion', 0.5)
        total_troops = sum(player_data['troops'].values())
        
        # Only consider expansion if we have enough troops
        if total_troops > 15 and expansion_drive > 0.4:
            expansion_target = self.find_expansion_target(player_id)
            if expansion_target:
                decisions.append({
                    'type': 'attack',
                    'target': expansion_target,
                    'priority': expansion_drive * 0.6
                })
        
        return decisions
    
    def find_attack_target(self, player_id: str) -> Optional[tuple]:
        """Find a suitable target for attack"""
        player_data = self.game_engine.state.players[player_id]
        territories = player_data.get('territories', [])
        
        # Find enemy territories adjacent to our territories
        possible_targets = []
        
        for tx, ty in territories:
            for dx in range(-1, 2):
                for dy in range(-1, 2):
                    if dx == 0 and dy == 0:
                        continue
                    
                    x, y = tx + dx, ty + dy
                    tile_key = f"{x},{y}"
                    
                    if tile_key in self.game_engine.state.map_data:
                        tile_data = self.game_engine.state.map_data[tile_key]
                        owner = tile_data.get('owner')
                        
                        # Target enemy territories or valuable neutral tiles
                        if owner and owner != player_id:
                            # Check if target is weaker
                            target_data = self.game_engine.state.players.get(owner)
                            if target_data:
                                target_troops = sum(target_data['troops'].values())
                                our_troops = sum(player_data['troops'].values())
                                
                                if our_troops > target_troops * 0.8:  # Attack if we have advantage
                                    possible_targets.append((x, y))
        
        return random.choice(possible_targets) if possible_targets else None
    
    def find_expansion_target(self, player_id: str) -> Optional[tuple]:
        """Find a suitable neutral tile for expansion"""
        player_data = self.game_engine.state.players[player_id]
        territories = player_data.get('territories', [])
        
        # Find neutral tiles adjacent to our territories
        possible_targets = []
        
        for tx, ty in territories:
            for dx in range(-1, 2):
                for dy in range(-1, 2):
                    if dx == 0 and dy == 0:
                        continue
                    
                    x, y = tx + dx, ty + dy
                    tile_key = f"{x},{y}"
                    
                    if tile_key in self.game_engine.state.map_data:
                        tile_data = self.game_engine.state.map_data[tile_key]
                        
                        # Target neutral tiles with good terrain
                        if (not tile_data.get('owner') and 
                            tile_data['terrain_type'] in ['grass', 'forest']):
                            possible_targets.append((x, y))
        
        return random.choice(possible_targets) if possible_targets else None
    
    def prioritize_decisions(self, decisions: List[Dict[str, Any]], personality: Dict) -> List[Dict[str, Any]]:
        """Sort decisions by priority"""
        # Add some randomness to prevent predictable behavior
        for decision in decisions:
            decision['priority'] += random.uniform(-0.1, 0.1)
        
        return sorted(decisions, key=lambda x: x['priority'], reverse=True)[:3]  # Top 3 decisions
    
    def execute_decision(self, player_id: str, decision: Dict[str, Any]):
        """Execute an AI decision"""
        try:
            if decision['type'] == 'upgrade_building':
                result = self.game_engine.upgrade_building(player_id, decision['building'])
                if result['success']:
                    logging.info(f"AI {player_id} upgraded {decision['building']}")
                
            elif decision['type'] == 'train_troops':
                result = self.game_engine.train_troops(
                    player_id, 
                    decision['troop_type'], 
                    decision['quantity']
                )
                if result['success']:
                    logging.info(f"AI {player_id} trained {decision['quantity']} {decision['troop_type']}")
                
            elif decision['type'] == 'attack':
                x, y = decision['target']
                result = self.game_engine.attack_tile(player_id, x, y)
                if result['success']:
                    battle_result = result['battle_result']
                    logging.info(f"AI {player_id} attacked ({x},{y}) - {battle_result['winner']} won")
                    
        except Exception as e:
            logging.error(f"Error executing AI decision for {player_id}: {e}")
