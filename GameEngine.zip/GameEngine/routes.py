from flask import render_template, request, jsonify, session, redirect, url_for
from app import app, game_engine
from heroes import HeroSystem
import logging

@app.route('/')
def index():
    """Main game page"""
    player_id = session.get('player_id')
    if not player_id:
        return render_template('index.html', show_welcome=True)
    
    # Get player data
    game_view = game_engine.get_player_view(player_id)
    if not game_view:
        # Player doesn't exist, clear session
        session.pop('player_id', None)
        return render_template('index.html', show_welcome=True)
    
    leaderboard = game_engine.get_leaderboard()
    
    # Get available heroes
    available_heroes = HeroSystem.get_available_heroes()
    
    return render_template('index.html', 
                         game_view=game_view, 
                         leaderboard=leaderboard,
                         available_heroes=available_heroes,
                         show_welcome=False)

@app.route('/create_player', methods=['POST'])
def create_player():
    """Create a new human player"""
    name = request.form.get('name', '').strip()
    if not name:
        return jsonify({'success': False, 'message': 'Name is required'})
    
    try:
        player_id = game_engine.create_human_player(name)
        session['player_id'] = player_id
        return jsonify({'success': True, 'message': 'Player created successfully'})
    except Exception as e:
        logging.error(f"Error creating player: {e}")
        return jsonify({'success': False, 'message': 'Failed to create player'})

@app.route('/get_game_state')
def get_game_state():
    """Get current game state for player"""
    player_id = session.get('player_id')
    if not player_id:
        return jsonify({'error': 'No player logged in'})
    
    game_view = game_engine.get_player_view(player_id)
    leaderboard = game_engine.get_leaderboard()
    
    return jsonify({
        'game_view': game_view,
        'leaderboard': leaderboard
    })

@app.route('/upgrade_building', methods=['POST'])
def upgrade_building():
    """Upgrade a building"""
    player_id = session.get('player_id')
    if not player_id:
        return jsonify({'success': False, 'message': 'Not logged in'})
    
    data = request.get_json()
    building_name = data.get('building_name')
    
    if not building_name:
        return jsonify({'success': False, 'message': 'Building name required'})
    
    result = game_engine.upgrade_building(player_id, building_name)
    return jsonify(result)

@app.route('/train_troops', methods=['POST'])
def train_troops():
    """Train troops"""
    player_id = session.get('player_id')
    if not player_id:
        return jsonify({'success': False, 'message': 'Not logged in'})
    
    data = request.get_json()
    troop_type = data.get('troop_type')
    quantity = data.get('quantity', 1)
    
    if not troop_type:
        return jsonify({'success': False, 'message': 'Troop type required'})
    
    try:
        quantity = int(quantity)
        if quantity <= 0:
            return jsonify({'success': False, 'message': 'Invalid quantity'})
    except ValueError:
        return jsonify({'success': False, 'message': 'Invalid quantity'})
    
    result = game_engine.train_troops(player_id, troop_type, quantity)
    return jsonify(result)

@app.route('/attack_tile', methods=['POST'])
def attack_tile():
    """Attack a tile"""
    player_id = session.get('player_id')
    if not player_id:
        return jsonify({'success': False, 'message': 'Not logged in'})
    
    data = request.get_json()
    x = data.get('x')
    y = data.get('y')
    
    if x is None or y is None:
        return jsonify({'success': False, 'message': 'Coordinates required'})
    
    try:
        x, y = int(x), int(y)
    except ValueError:
        return jsonify({'success': False, 'message': 'Invalid coordinates'})
    
    result = game_engine.attack_tile(player_id, x, y)
    return jsonify(result)

@app.route('/get_tile_info/<int:x>/<int:y>')
def get_tile_info(x, y):
    """Get information about a specific tile"""
    player_id = session.get('player_id')
    if not player_id:
        return jsonify({'error': 'Not logged in'})
    
    tile_key = f"{x},{y}"
    game_view = game_engine.get_player_view(player_id)
    
    if tile_key in game_view.get('visible_tiles', {}):
        tile_data = game_view['visible_tiles'][tile_key]
        
        # Add additional info if owned by player
        if tile_data.get('owner') == player_id:
            tile_data['can_build'] = True
        
        # Check if tile can be attacked
        tile_data['can_attack'] = (
            tile_data.get('owner') != player_id and 
            game_engine._is_adjacent_to_territory(player_id, x, y)
        )
        
        return jsonify({'tile': tile_data})
    
    return jsonify({'error': 'Tile not visible'})

@app.route('/recruit_hero', methods=['POST'])
def recruit_hero():
    """Recruit a hero"""
    player_id = session.get('player_id')
    if not player_id:
        return jsonify({'success': False, 'message': 'Not logged in'})
    
    try:
        data = request.get_json()
        hero_id = data.get('hero_id')
        
        # Get player data
        player_data = game_engine.state.players.get(player_id)
        if not player_data:
            return jsonify({'success': False, 'message': 'Player not found'})
        
        # Try to recruit hero
        success = HeroSystem.recruit_hero(player_data, hero_id)
        
        if success:
            game_engine.save_game_state()
            hero = HeroSystem.get_hero_by_id(hero_id)
            return jsonify({'success': True, 'message': f'Recruited {hero.get("name", "Hero")}!'})
        else:
            return jsonify({'success': False, 'message': 'Cannot recruit hero - insufficient resources'})
    except Exception as e:
        logging.error(f"Error recruiting hero: {e}")
        return jsonify({'success': False, 'message': 'Error occurred'})

@app.route('/get_heroes')
def get_heroes():
    """Get available heroes"""
    return jsonify(HeroSystem.get_available_heroes())

@app.route('/logout')
def logout():
    """Logout player"""
    session.pop('player_id', None)
    return redirect(url_for('index'))

@app.errorhandler(404)
def not_found(error):
    return render_template('index.html', show_welcome=True), 404

@app.errorhandler(500)
def internal_error(error):
    logging.error(f"Internal error: {error}")
    return render_template('index.html', show_welcome=True), 500
