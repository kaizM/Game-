import json
import os
import random
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
from models import GameState, Player, Tile, Army
from heroes import HeroSystem

class GameEngine:
    def __init__(self):
        self.game_state_file = 'game_state.json'
        self.state = self.load_game_state()
        self.initialize_game()
        
    def load_game_state(self) -> GameState:
        """Load game state from JSON file"""
        if os.path.exists(self.game_state_file):
            try:
                with open(self.game_state_file, 'r') as f:
                    data = json.load(f)
                    return GameState.from_dict(data)
            except Exception as e:
                logging.error(f"Error loading game state: {e}")
                return GameState()
        return GameState()
    
    def save_game_state(self):
        """Save game state to JSON file"""
        try:
            with open(self.game_state_file, 'w') as f:
                json.dump(self.state.to_dict(), f, indent=2)
        except Exception as e:
            logging.error(f"Error saving game state: {e}")
    
    def initialize_game(self):
        """Initialize game if not already done"""
        if not self.state.map_data:
            self.generate_map()
            self.create_ai_players()
            self.save_game_state()
    
    def generate_map(self):
        """Generate the game map with terrain and resources"""
        size = self.state.game_config['map_size']
        
        for x in range(size):
            for y in range(size):
                # Generate terrain based on position and randomness
                terrain = self._determine_terrain(x, y, size)
                tile = Tile(x, y, terrain)
                self.state.map_data[f"{x},{y}"] = tile.to_dict()
    
    def _determine_terrain(self, x: int, y: int, size: int) -> str:
        """Determine terrain type based on position"""
        # Center area more likely to be grass
        center_x, center_y = size // 2, size // 2
        distance_from_center = ((x - center_x) ** 2 + (y - center_y) ** 2) ** 0.5
        
        # Edge areas more likely to be water/mountains
        edge_distance = min(x, y, size - 1 - x, size - 1 - y)
        
        rand = random.random()
        
        if edge_distance < 3 and rand < 0.4:
            return 'water'
        elif distance_from_center > size * 0.3 and rand < 0.3:
            return 'mountain'
        elif rand < 0.25:
            return 'forest'
        elif rand < 0.05:
            return 'desert'
        else:
            return 'grass'
    
    def create_ai_players(self):
        """Create AI players and place them on the map"""
        ai_names = ['King Aldric', 'Queen Moira', 'Lord Gareth', 'Duke Magnus', 'Baron Theron']
        
        for i, name in enumerate(ai_names):
            player_id = f"ai_{i+1}"
            player = Player(player_id, name, is_ai=True)
            
            # Find suitable starting position
            position = self._find_starting_position()
            if position:
                player.city_position = position
                player.territories = [position]
                
                # Place city on map
                tile_key = f"{position[0]},{position[1]}"
                if tile_key in self.state.map_data:
                    self.state.map_data[tile_key]['owner'] = player_id
                    self.state.map_data[tile_key]['building'] = 'city'
            
            self.state.players[player_id] = player.__dict__
    
    def _find_starting_position(self) -> Optional[Tuple[int, int]]:
        """Find a suitable starting position for a player"""
        size = self.state.game_config['map_size']
        attempts = 0
        
        while attempts < 100:
            x = random.randint(5, size - 6)
            y = random.randint(5, size - 6)
            
            tile_key = f"{x},{y}"
            if (tile_key in self.state.map_data and 
                self.state.map_data[tile_key]['terrain_type'] == 'grass' and
                not self.state.map_data[tile_key]['owner']):
                
                # Check if position is far enough from other players
                if self._is_position_isolated(x, y, min_distance=10):
                    return (x, y)
            
            attempts += 1
        
        return None
    
    def _is_position_isolated(self, x: int, y: int, min_distance: int) -> bool:
        """Check if position is far enough from other players"""
        for player_data in self.state.players.values():
            if player_data['city_position']:
                px, py = player_data['city_position']
                distance = ((x - px) ** 2 + (y - py) ** 2) ** 0.5
                if distance < min_distance:
                    return False
        return True
    
    def create_human_player(self, name: str) -> str:
        """Create a human player"""
        player_id = f"human_{len([p for p in self.state.players.values() if not p['is_ai']]) + 1}"
        player = Player(player_id, name, is_ai=False)
        
        position = self._find_starting_position()
        if position:
            player.city_position = position
            player.territories = [position]
            
            # Place city on map
            tile_key = f"{position[0]},{position[1]}"
            if tile_key in self.state.map_data:
                self.state.map_data[tile_key]['owner'] = player_id
                self.state.map_data[tile_key]['building'] = 'city'
        
        self.state.players[player_id] = player.__dict__
        self.save_game_state()
        return player_id
    
    def tick(self):
        """Process one game tick - resource generation, building completion, etc."""
        self.state.current_tick += 1
        self.state.last_update = datetime.now().isoformat()
        
        for player_id, player_data in self.state.players.items():
            self._process_player_tick(player_id, player_data)
        
        self.save_game_state()
        logging.info(f"Game tick {self.state.current_tick} processed")
    
    def _process_player_tick(self, player_id: str, player_data: Dict):
        """Process tick for individual player"""
        # Resource generation
        self._generate_resources(player_id, player_data)
        
        # Complete building upgrades
        self._complete_building_upgrades(player_id, player_data)
        
        # Complete troop training
        self._complete_troop_training(player_id, player_data)
        
        # Process troop upkeep
        self._process_troop_upkeep(player_id, player_data)
    
    def _generate_resources(self, player_id: str, player_data: Dict):
        """Generate resources based on buildings"""
        buildings = player_data['buildings']
        resources = player_data['resources']
        
        # Base production rates
        production = {
            'food': buildings['farm']['level'] * 50,
            'wood': buildings['lumber_mill']['level'] * 40,
            'stone': buildings['quarry']['level'] * 30,
            'gold': buildings['gold_mine']['level'] * 20
        }
        
        # Apply town hall bonus
        town_hall_bonus = 1 + (buildings['town_hall']['level'] - 1) * 0.1
        
        for resource, amount in production.items():
            resources[resource] += int(amount * town_hall_bonus)
            # Cap resources at reasonable limits
            resources[resource] = min(resources[resource], 50000)
    
    def _complete_building_upgrades(self, player_id: str, player_data: Dict):
        """Complete building upgrades that are ready"""
        buildings = player_data['buildings']
        current_tick = self.state.current_tick
        
        for building_name, building_data in buildings.items():
            if (building_data['upgrading'] and 
                current_tick >= building_data['upgrade_complete_tick']):
                building_data['level'] += 1
                building_data['upgrading'] = False
                building_data['upgrade_complete_tick'] = 0
                logging.info(f"Player {player_id} completed {building_name} upgrade to level {building_data['level']}")
    
    def _complete_troop_training(self, player_id: str, player_data: Dict):
        """Complete troop training that is ready"""
        current_tick = self.state.current_tick
        training_queue = player_data['training_queue']
        troops = player_data['troops']
        
        completed_training = []
        for i, training in enumerate(training_queue):
            if current_tick >= training['complete_tick']:
                troops[training['troop_type']] += training['quantity']
                completed_training.append(i)
                logging.info(f"Player {player_id} completed training {training['quantity']} {training['troop_type']}")
        
        # Remove completed training in reverse order
        for i in reversed(completed_training):
            training_queue.pop(i)
    
    def _process_troop_upkeep(self, player_id: str, player_data: Dict):
        """Process troop upkeep costs"""
        troops = player_data['troops']
        resources = player_data['resources']
        
        total_upkeep = 0
        for troop_type, count in troops.items():
            upkeep_cost = {'infantry': 2, 'archer': 2, 'cavalry': 3}.get(troop_type, 2)
            total_upkeep += count * upkeep_cost
        
        if resources['food'] >= total_upkeep:
            resources['food'] -= total_upkeep
        else:
            # If can't pay upkeep, lose some troops
            shortage = total_upkeep - resources['food']
            resources['food'] = 0
            troops_lost = min(shortage // 5, sum(troops.values()) // 10)
            
            if troops_lost > 0:
                # Remove troops randomly
                for _ in range(troops_lost):
                    available_types = [t for t, c in troops.items() if c > 0]
                    if available_types:
                        troop_type = random.choice(available_types)
                        troops[troop_type] -= 1
                        
                logging.warning(f"Player {player_id} lost {troops_lost} troops due to food shortage")
    
    def upgrade_building(self, player_id: str, building_name: str) -> Dict[str, Any]:
        """Attempt to upgrade a building"""
        if player_id not in self.state.players:
            return {'success': False, 'message': 'Player not found'}
        
        player_data = self.state.players[player_id]
        buildings = player_data['buildings']
        resources = player_data['resources']
        
        if building_name not in buildings:
            return {'success': False, 'message': 'Building not found'}
        
        building = buildings[building_name]
        
        if building['upgrading']:
            return {'success': False, 'message': 'Building is already upgrading'}
        
        if building['level'] >= 25:
            return {'success': False, 'message': 'Building is at maximum level'}
        
        # Calculate upgrade cost and time
        cost = self._calculate_building_cost(building_name, building['level'])
        upgrade_time = self._calculate_building_time(building_name, building['level'])
        
        # Check if player has enough resources
        for resource, amount in cost.items():
            if resources.get(resource, 0) < amount:
                return {'success': False, 'message': f'Not enough {resource}'}
        
        # Deduct resources and start upgrade
        for resource, amount in cost.items():
            resources[resource] -= amount
        
        building['upgrading'] = True
        building['upgrade_complete_tick'] = self.state.current_tick + upgrade_time
        
        self.save_game_state()
        return {'success': True, 'message': f'{building_name} upgrade started'}
    
    def _calculate_building_cost(self, building_name: str, current_level: int) -> Dict[str, int]:
        """Calculate the cost to upgrade a building"""
        base_costs = {
            'town_hall': {'wood': 1000, 'stone': 1000, 'gold': 500},
            'farm': {'wood': 200, 'stone': 100},
            'lumber_mill': {'wood': 150, 'stone': 150},
            'quarry': {'wood': 100, 'stone': 200},
            'gold_mine': {'wood': 300, 'stone': 300, 'gold': 100},
            'barracks': {'wood': 500, 'stone': 300},
            'archery_range': {'wood': 400, 'stone': 200},
            'stables': {'wood': 600, 'stone': 400, 'gold': 200},
            'academy': {'wood': 800, 'stone': 600, 'gold': 400},
            'wall': {'stone': 500, 'wood': 200}
        }
        
        cost = base_costs.get(building_name, {'wood': 100, 'stone': 100})
        multiplier = 1.5 ** current_level
        
        return {resource: int(amount * multiplier) for resource, amount in cost.items()}
    
    def _calculate_building_time(self, building_name: str, current_level: int) -> int:
        """Calculate the time in ticks to upgrade a building"""
        base_times = {
            'town_hall': 20,
            'farm': 5,
            'lumber_mill': 5,
            'quarry': 5,
            'gold_mine': 8,
            'barracks': 10,
            'archery_range': 8,
            'stables': 12,
            'academy': 15,
            'wall': 6
        }
        
        base_time = base_times.get(building_name, 5)
        return base_time + current_level * 2
    
    def train_troops(self, player_id: str, troop_type: str, quantity: int) -> Dict[str, Any]:
        """Train troops for a player"""
        if player_id not in self.state.players:
            return {'success': False, 'message': 'Player not found'}
        
        player_data = self.state.players[player_id]
        buildings = player_data['buildings']
        resources = player_data['resources']
        
        # Check if player has required building
        required_building = {'infantry': 'barracks', 'archer': 'archery_range', 'cavalry': 'stables'}
        building_name = required_building.get(troop_type)
        
        if not building_name or buildings[building_name]['level'] == 0:
            return {'success': False, 'message': f'Required building not available for {troop_type}'}
        
        # Calculate cost and time
        cost = self._calculate_troop_cost(troop_type, quantity)
        train_time = self._calculate_train_time(troop_type, quantity, buildings[building_name]['level'])
        
        # Check resources
        for resource, amount in cost.items():
            if resources.get(resource, 0) < amount:
                return {'success': False, 'message': f'Not enough {resource}'}
        
        # Deduct resources and add to training queue
        for resource, amount in cost.items():
            resources[resource] -= amount
        
        training = {
            'troop_type': troop_type,
            'quantity': quantity,
            'complete_tick': self.state.current_tick + train_time
        }
        
        player_data['training_queue'].append(training)
        self.save_game_state()
        
        return {'success': True, 'message': f'Training {quantity} {troop_type} started'}
    
    def _calculate_troop_cost(self, troop_type: str, quantity: int) -> Dict[str, int]:
        """Calculate cost to train troops"""
        unit_costs = {
            'infantry': {'food': 50, 'wood': 30},
            'archer': {'food': 40, 'wood': 50},
            'cavalry': {'food': 80, 'wood': 60, 'gold': 20}
        }
        
        unit_cost = unit_costs.get(troop_type, {'food': 50, 'wood': 30})
        return {resource: amount * quantity for resource, amount in unit_cost.items()}
    
    def _calculate_train_time(self, troop_type: str, quantity: int, building_level: int) -> int:
        """Calculate time to train troops in ticks"""
        base_times = {'infantry': 3, 'archer': 4, 'cavalry': 6}
        base_time = base_times.get(troop_type, 3)
        
        # Higher building level reduces training time
        time_reduction = min(building_level * 0.1, 0.5)
        actual_time = max(1, int(base_time * (1 - time_reduction)))
        
        return actual_time * quantity
    
    def attack_tile(self, attacker_id: str, target_x: int, target_y: int) -> Dict[str, Any]:
        """Attack a tile with player's army"""
        if attacker_id not in self.state.players:
            return {'success': False, 'message': 'Player not found'}
        
        tile_key = f"{target_x},{target_y}"
        if tile_key not in self.state.map_data:
            return {'success': False, 'message': 'Invalid target location'}
        
        tile_data = self.state.map_data[tile_key]
        attacker_data = self.state.players[attacker_id]
        
        # Check if tile is adjacent to player's territory
        if not self._is_adjacent_to_territory(attacker_id, target_x, target_y):
            return {'success': False, 'message': 'Target is not adjacent to your territory'}
        
        # Get attacking army
        attacking_army = attacker_data['troops'].copy()
        if sum(attacking_army.values()) == 0:
            return {'success': False, 'message': 'No troops available to attack'}
        
        # Determine defender
        defender_id = tile_data.get('owner')
        defender_army = {}
        
        if defender_id and defender_id in self.state.players:
            # Defending with a portion of defender's army
            defender_data = self.state.players[defender_id]
            for troop_type, count in defender_data['troops'].items():
                defender_army[troop_type] = count // 4  # Use 25% of army for defense
        
        # Resolve combat
        battle_result = self._resolve_combat(attacking_army, defender_army)
        
        # Apply losses
        for troop_type, losses in battle_result['attacker_losses'].items():
            attacker_data['troops'][troop_type] -= losses
        
        if defender_id and defender_id in self.state.players:
            defender_data = self.state.players[defender_id]
            for troop_type, losses in battle_result['defender_losses'].items():
                defender_data['troops'][troop_type] -= losses
        
        # If attacker wins, capture tile
        if battle_result['winner'] == 'attacker':
            tile_data['owner'] = attacker_id
            attacker_data['territories'].append((target_x, target_y))
            
            if defender_id and defender_id in self.state.players:
                defender_data = self.state.players[defender_id]
                if (target_x, target_y) in defender_data['territories']:
                    defender_data['territories'].remove((target_x, target_y))
        
        self.save_game_state()
        return {'success': True, 'battle_result': battle_result}
    
    def _is_adjacent_to_territory(self, player_id: str, x: int, y: int) -> bool:
        """Check if tile is adjacent to player's territory"""
        player_data = self.state.players[player_id]
        territories = player_data.get('territories', [])
        
        for tx, ty in territories:
            if abs(x - tx) <= 1 and abs(y - ty) <= 1:
                return True
        
        return False
    
    def _resolve_combat(self, attacker: Dict[str, int], defender: Dict[str, int]) -> Dict[str, Any]:
        """Resolve combat between two armies"""
        # Calculate combat power
        attacker_power = 0
        defender_power = 0
        
        unit_power = {'infantry': 15, 'archer': 12, 'cavalry': 20}
        
        for troop_type, count in attacker.items():
            attacker_power += count * unit_power.get(troop_type, 10)
        
        for troop_type, count in defender.items():
            defender_power += count * unit_power.get(troop_type, 10)
        
        # Add some randomness
        attacker_power *= random.uniform(0.8, 1.2)
        defender_power *= random.uniform(0.8, 1.2)
        
        # Defender gets advantage
        defender_power *= 1.2
        
        # Determine winner
        winner = 'attacker' if attacker_power > defender_power else 'defender'
        
        # Calculate losses (loser loses more)
        if winner == 'attacker':
            attacker_loss_rate = 0.2
            defender_loss_rate = 0.6
        else:
            attacker_loss_rate = 0.7
            defender_loss_rate = 0.3
        
        attacker_losses = {}
        defender_losses = {}
        
        for troop_type, count in attacker.items():
            losses = int(count * attacker_loss_rate * random.uniform(0.5, 1.5))
            attacker_losses[troop_type] = min(losses, count)
        
        for troop_type, count in defender.items():
            losses = int(count * defender_loss_rate * random.uniform(0.5, 1.5))
            defender_losses[troop_type] = min(losses, count)
        
        return {
            'winner': winner,
            'attacker_power': int(attacker_power),
            'defender_power': int(defender_power),
            'attacker_losses': attacker_losses,
            'defender_losses': defender_losses
        }
    
    def get_player_view(self, player_id: str) -> Dict[str, Any]:
        """Get the game view for a specific player"""
        if player_id not in self.state.players:
            return {}
        
        player_data = self.state.players[player_id]
        
        # Get visible map tiles
        visible_tiles = {}
        territories = player_data.get('territories', [])
        
        for tx, ty in territories:
            # Player can see their territories and adjacent tiles
            for dx in range(-2, 3):
                for dy in range(-2, 3):
                    x, y = tx + dx, ty + dy
                    tile_key = f"{x},{y}"
                    if tile_key in self.state.map_data:
                        visible_tiles[tile_key] = self.state.map_data[tile_key]
        
        return {
            'player': player_data,
            'visible_tiles': visible_tiles,
            'current_tick': self.state.current_tick,
            'game_config': self.state.game_config
        }
    
    def get_leaderboard(self) -> List[Dict[str, Any]]:
        """Get player rankings"""
        rankings = []
        
        for player_id, player_data in self.state.players.items():
            score = 0
            score += len(player_data.get('territories', [])) * 100
            score += sum(player_data.get('troops', {}).values()) * 10
            score += sum(player_data.get('resources', {}).values()) // 100
            
            rankings.append({
                'player_id': player_id,
                'name': player_data['name'],
                'score': score,
                'territories': len(player_data.get('territories', [])),
                'total_troops': sum(player_data.get('troops', {}).values()),
                'is_ai': player_data.get('is_ai', False)
            })
        
        return sorted(rankings, key=lambda x: x['score'], reverse=True)
