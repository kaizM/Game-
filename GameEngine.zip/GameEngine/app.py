import os
import logging
from flask import Flask
from apscheduler.schedulers.background import BackgroundScheduler
import atexit

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "medieval-strategy-game-secret-key")

# Initialize game state and scheduler
from game_logic import GameEngine
from ai_logic import AIEngine

game_engine = GameEngine()
ai_engine = AIEngine(game_engine)

# Set up scheduler for game ticks
scheduler = BackgroundScheduler()
scheduler.add_job(func=game_engine.tick, trigger="interval", seconds=30, id='game_tick')
scheduler.add_job(func=ai_engine.process_ai_turns, trigger="interval", seconds=60, id='ai_tick')
scheduler.start()

# Shut down the scheduler when exiting the app
atexit.register(lambda: scheduler.shutdown())

# Import routes after app initialization
from routes import *


