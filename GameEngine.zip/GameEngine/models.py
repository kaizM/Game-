import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

class GameState:
    def __init__(self):
        self.players = {}
        self.map_data = {}
        self.game_config = {
            'map_size': 50,
            'tick_interval': 30,
            'max_players': 8
        }
        self.current_tick = 0
        self.last_update = datetime.now().isoformat()
        
    def to_dict(self) -> Dict[str, Any]:
        return {
            'players': self.players,
            'map_data': self.map_data,
            'game_config': self.game_config,
            'current_tick': self.current_tick,
            'last_update': self.last_update
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GameState':
        state = cls()
        state.players = data.get('players', {})
        state.map_data = data.get('map_data', {})
        state.game_config = data.get('game_config', state.game_config)
        state.current_tick = data.get('current_tick', 0)
        state.last_update = data.get('last_update', datetime.now().isoformat())
        return state

class Player:
    def __init__(self, player_id: str, name: str, is_ai: bool = False):
        self.player_id = player_id
        self.name = name
        self.is_ai = is_ai
        self.resources = {'food': 1000, 'wood': 1000, 'stone': 500, 'gold': 500, 'gems': 10}
        self.heroes = {}
        self.buildings = {
            'town_hall': {'level': 1, 'upgrading': False, 'upgrade_complete_tick': 0},
            'farm': {'level': 1, 'upgrading': False, 'upgrade_complete_tick': 0},
            'lumber_mill': {'level': 1, 'upgrading': False, 'upgrade_complete_tick': 0},
            'quarry': {'level': 1, 'upgrading': False, 'upgrade_complete_tick': 0},
            'gold_mine': {'level': 1, 'upgrading': False, 'upgrade_complete_tick': 0},
            'barracks': {'level': 1, 'upgrading': False, 'upgrade_complete_tick': 0},
            'archery_range': {'level': 0, 'upgrading': False, 'upgrade_complete_tick': 0},
            'stables': {'level': 0, 'upgrading': False, 'upgrade_complete_tick': 0},
            'academy': {'level': 0, 'upgrading': False, 'upgrade_complete_tick': 0},
            'wall': {'level': 1, 'upgrading': False, 'upgrade_complete_tick': 0}
        }
        self.troops = {'infantry': 10, 'archer': 5, 'cavalry': 0}
        self.training_queue = []
        self.research = {}
        self.city_position: Optional[Tuple[int, int]] = None
        self.territories = []
        self.ai_personality = self._generate_ai_personality() if is_ai else None
        
    def _generate_ai_personality(self) -> Dict[str, float]:
        """Generate AI personality weights for decision making"""
        import random
        return {
            'aggression': random.uniform(0.2, 0.8),
            'expansion': random.uniform(0.3, 0.9),
            'economy': random.uniform(0.4, 0.9),
            'defense': random.uniform(0.3, 0.8),
            'diplomacy': random.uniform(0.1, 0.7)
        }

class Tile:
    def __init__(self, x: int, y: int, terrain_type: str = 'grass'):
        self.x = x
        self.y = y
        self.terrain_type = terrain_type  # grass, forest, mountain, water, desert
        self.owner = None
        self.occupied_by = None
        self.visible_to = []
        self.resources = self._generate_resources()
        self.building = None
        
    def _generate_resources(self) -> Dict[str, int]:
        """Generate resource nodes based on terrain type"""
        import random
        resources = {'food': 0, 'wood': 0, 'stone': 0, 'gold': 0}
        
        if self.terrain_type == 'forest':
            if random.random() < 0.3:
                resources['wood'] = random.randint(500, 1500)
        elif self.terrain_type == 'mountain':
            if random.random() < 0.4:
                resources['stone'] = random.randint(300, 1000)
            if random.random() < 0.1:
                resources['gold'] = random.randint(100, 500)
        elif self.terrain_type == 'grass':
            if random.random() < 0.2:
                resources['food'] = random.randint(200, 800)
                
        return resources
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'x': self.x,
            'y': self.y,
            'terrain_type': self.terrain_type,
            'owner': self.owner,
            'occupied_by': self.occupied_by,
            'visible_to': self.visible_to,
            'resources': self.resources,
            'building': self.building
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Tile':
        tile = cls(data['x'], data['y'], data['terrain_type'])
        tile.owner = data.get('owner')
        tile.occupied_by = data.get('occupied_by')
        tile.visible_to = data.get('visible_to', [])
        tile.resources = data.get('resources', {})
        tile.building = data.get('building')
        return tile

class Army:
    def __init__(self, army_id: str, owner: str, position: tuple, troops: Dict[str, int]):
        self.army_id = army_id
        self.owner = owner
        self.position = position  # (x, y)
        self.troops = troops
        self.commander = None
        self.target_position = None
        self.movement_progress = 0
        self.status = 'idle'  # idle, moving, fighting, gathering
        
    def get_total_troops(self) -> int:
        return sum(self.troops.values())
    
    def get_combat_power(self) -> int:
        power = 0
        power += self.troops.get('infantry', 0) * 15
        power += self.troops.get('archer', 0) * 12
        power += self.troops.get('cavalry', 0) * 20
        return power
