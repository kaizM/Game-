// UI Management Module
const UI = {
    // Initialize UI components
    init: function() {
        this.setupTooltip();
        this.setupNotifications();
    },
    
    // Setup tooltip element
    setupTooltip: function() {
        this.tooltip = document.getElementById('mapTooltip');
    },
    
    // Setup notification system
    setupNotifications: function() {
        // Create notification container if it doesn't exist
        if (!document.getElementById('notification-container')) {
            const container = document.createElement('div');
            container.id = 'notification-container';
            container.style.cssText = `
                position: fixed;
                top: 80px;
                right: 20px;
                z-index: 1050;
                width: 300px;
            `;
            document.body.appendChild(container);
        }
    },
    
    // Show tooltip
    showTooltip: function(x, y, content) {
        if (this.tooltip) {
            this.tooltip.innerHTML = content;
            this.tooltip.style.left = (x + 10) + 'px';
            this.tooltip.style.top = (y + 10) + 'px';
            this.tooltip.style.display = 'block';
        }
    },
    
    // Hide tooltip
    hideTooltip: function() {
        if (this.tooltip) {
            this.tooltip.style.display = 'none';
        }
    },
    
    // Show notification message
    showMessage: function(message, type = 'info') {
        const container = document.getElementById('notification-container');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show`;
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        container.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 5000);
    },
    
    // Update resource display
    updateResources: function(resources) {
        this.updateCounter('foodCount', resources.food);
        this.updateCounter('woodCount', resources.wood);
        this.updateCounter('stoneCount', resources.stone);
        this.updateCounter('goldCount', resources.gold);
        this.updateCounter('gemCount', resources.gems);
    },
    
    // Update troop display
    updateTroops: function(troops) {
        this.updateCounter('infantryCount', troops.infantry || 0);
        this.updateCounter('archerCount', troops.archer || 0);
        this.updateCounter('cavalryCount', troops.cavalry || 0);
        
        const totalTroops = (troops.infantry || 0) + (troops.archer || 0) + (troops.cavalry || 0);
        this.updateCounter('totalTroops', totalTroops);
    },
    
    // Update current tick display
    updateTick: function(tick) {
        this.updateCounter('currentTick', tick);
    },
    
    // Update a counter element with animation
    updateCounter: function(elementId, newValue) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        const currentValue = parseInt(element.textContent) || 0;
        
        if (newValue !== currentValue) {
            // Add animation class
            element.classList.add('updating');
            
            // Animate the change
            this.animateValue(element, currentValue, newValue, 500);
            
            // Remove animation class after animation
            setTimeout(() => {
                element.classList.remove('updating');
            }, 500);
        }
    },
    
    // Animate value change
    animateValue: function(element, start, end, duration) {
        const startTime = performance.now();
        const difference = end - start;
        
        const step = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const currentValue = Math.floor(start + (difference * progress));
            element.textContent = this.formatNumber(currentValue);
            
            if (progress < 1) {
                requestAnimationFrame(step);
            }
        };
        
        requestAnimationFrame(step);
    },
    
    // Format number with commas
    formatNumber: function(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },
    
    // Update building states
    updateBuildings: function(buildings) {
        for (const [buildingName, buildingData] of Object.entries(buildings)) {
            const buildingElement = document.querySelector(`[data-building="${buildingName}"]`);
            if (buildingElement) {
                const levelElement = buildingElement.querySelector('.text-muted');
                const button = buildingElement.querySelector('.upgrade-building');
                
                if (levelElement) {
                    let text = `Level ${buildingData.level}`;
                    if (buildingData.upgrading) {
                        text += ' <span class="badge bg-warning">Upgrading...</span>';
                        buildingElement.classList.add('building-upgrading');
                    } else {
                        buildingElement.classList.remove('building-upgrading');
                    }
                    levelElement.innerHTML = text;
                }
                
                if (button) {
                    if (buildingData.upgrading || buildingData.level >= 25) {
                        button.style.display = 'none';
                    } else {
                        button.style.display = 'block';
                    }
                }
            }
        }
    },
    
    // Update building states based on completion tick
    updateBuildingStates: function(buildings, currentTick) {
        for (const [buildingName, buildingData] of Object.entries(buildings)) {
            if (buildingData.upgrading && currentTick >= buildingData.upgrade_complete_tick) {
                // Building upgrade should be complete - refresh game state
                Game.updateGameState();
                break;
            }
        }
    },
    
    // Update training queue display
    updateTrainingQueue: function(trainingQueue) {
        const container = document.querySelector('.training-queue');
        if (!container && trainingQueue.length > 0) {
            // Create training queue display
            const militaryCard = document.querySelector('#military .card:last-child .card-body');
            if (militaryCard) {
                const queueDiv = document.createElement('div');
                queueDiv.className = 'training-queue mt-3';
                queueDiv.innerHTML = '<h6>Training Queue</h6>';
                militaryCard.appendChild(queueDiv);
            }
        }
        
        const queueContainer = document.querySelector('.training-queue');
        if (queueContainer) {
            // Clear existing queue items (except header)
            const items = queueContainer.querySelectorAll('.training-item');
            items.forEach(item => item.remove());
            
            // Add current queue items
            trainingQueue.forEach(training => {
                const item = document.createElement('div');
                item.className = 'training-item';
                item.innerHTML = `
                    <small>${training.quantity} ${training.troop_type} - Completing at tick ${training.complete_tick}</small>
                `;
                queueContainer.appendChild(item);
            });
            
            // Hide if no items
            if (trainingQueue.length === 0) {
                queueContainer.style.display = 'none';
            } else {
                queueContainer.style.display = 'block';
            }
        }
    },
    
    // Update leaderboard
    updateLeaderboard: function(leaderboard) {
        const container = document.querySelector('.leaderboard-panel');
        if (!container) return;
        
        let html = '';
        leaderboard.forEach((player, index) => {
            html += `
                <div class="leaderboard-item d-flex justify-content-between align-items-center p-2">
                    <div>
                        <span class="rank-number">#${index + 1}</span>
                        <strong>${player.name}</strong>
                        ${player.is_ai ? '<span class="badge bg-secondary">AI</span>' : ''}
                    </div>
                    <div class="text-end">
                        <div class="fw-bold">${this.formatNumber(player.score)}</div>
                        <small class="text-muted">${player.territories} territories</small>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    },
    
    // Set loading state
    setLoading: function(isLoading) {
        const buttons = document.querySelectorAll('button');
        buttons.forEach(button => {
            if (isLoading) {
                button.disabled = true;
                button.classList.add('loading');
            } else {
                button.disabled = false;
                button.classList.remove('loading');
            }
        });
    },
    
    // Show confirmation dialog
    showConfirmation: function(message, callback) {
        if (confirm(message)) {
            callback();
        }
    },
    
    // Update tab badges (for notifications)
    updateTabBadge: function(tabId, count) {
        const tab = document.querySelector(`#${tabId}-tab`);
        if (!tab) return;
        
        let badge = tab.querySelector('.badge');
        if (count > 0) {
            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'badge bg-danger ms-1';
                tab.appendChild(badge);
            }
            badge.textContent = count;
        } else if (badge) {
            badge.remove();
        }
    }
};

// Add CSS for updating animation
const style = document.createElement('style');
style.textContent = `
    .updating {
        color: #28a745 !important;
        font-weight: bold;
        transition: color 0.5s ease;
    }
    
    .building-upgrading {
        background: linear-gradient(45deg, #f8f9fa, #e9ecef);
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.7; }
        100% { opacity: 1; }
    }
`;
document.head.appendChild(style);

// Export for use in other files
window.UI = UI;
