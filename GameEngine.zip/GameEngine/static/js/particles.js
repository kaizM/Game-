// Particle Effects System
const ParticleSystem = {
    particles: [],
    canvas: null,
    ctx: null,
    
    init: function() {
        this.canvas = document.getElementById('gameMap');
        this.ctx = this.canvas.getContext('2d');
    },
    
    // Create resource collection particles
    createResourceParticles: function(x, y, resourceType) {
        const particleCount = 8;
        const colors = {
            food: '#4ade80',
            wood: '#a3a3a3',
            stone: '#6b7280',
            gold: '#fbbf24'
        };
        
        for (let i = 0; i < particleCount; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 4,
                vy: Math.random() * -3 - 1,
                life: 1.0,
                maxLife: 60,
                color: colors[resourceType] || '#ffffff',
                size: Math.random() * 3 + 2,
                gravity: 0.05
            });
        }
    },
    
    // Create building construction particles
    createBuildingParticles: function(x, y) {
        const particleCount = 12;
        
        for (let i = 0; i < particleCount; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 6,
                vy: Math.random() * -4 - 2,
                life: 1.0,
                maxLife: 90,
                color: '#ffd700',
                size: Math.random() * 4 + 1,
                gravity: 0.03,
                sparkle: true
            });
        }
    },
    
    // Create territory capture particles
    createTerritoryParticles: function(x, y, isPlayer) {
        const particleCount = 15;
        const color = isPlayer ? '#3b82f6' : '#ef4444';
        
        for (let i = 0; i < particleCount; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 5,
                vy: (Math.random() - 0.5) * 5,
                life: 1.0,
                maxLife: 120,
                color: color,
                size: Math.random() * 2 + 1,
                gravity: 0,
                glow: true
            });
        }
    },
    
    // Update and render all particles
    update: function() {
        if (!this.ctx) return;
        
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const particle = this.particles[i];
            
            // Update position
            particle.x += particle.vx;
            particle.y += particle.vy;
            particle.vy += particle.gravity;
            
            // Update life
            particle.life -= 1.0 / particle.maxLife;
            
            // Remove dead particles
            if (particle.life <= 0) {
                this.particles.splice(i, 1);
                continue;
            }
            
            // Render particle
            this.renderParticle(particle);
        }
    },
    
    // Render individual particle
    renderParticle: function(particle) {
        const alpha = particle.life;
        const size = particle.size * alpha;
        
        this.ctx.save();
        
        if (particle.glow) {
            this.ctx.shadowColor = particle.color;
            this.ctx.shadowBlur = 10 * alpha;
        }
        
        if (particle.sparkle) {
            // Sparkle effect
            this.ctx.fillStyle = `rgba(255, 255, 255, ${alpha * 0.8})`;
        } else {
            this.ctx.fillStyle = particle.color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
        }
        
        this.ctx.beginPath();
        this.ctx.arc(particle.x, particle.y, size, 0, 2 * Math.PI);
        this.ctx.fill();
        
        this.ctx.restore();
    },
    
    // Clear all particles
    clear: function() {
        this.particles = [];
    }
};

// Export for use in other files
window.ParticleSystem = ParticleSystem;