// Map Rendering Module
const GameMap = {
    canvas: null,
    ctx: null,
    tileSize: 16,
    viewportX: 0,
    viewportY: 0,
    mapSize: 50,
    
    // Enhanced terrain colors with gradients
    terrainColors: {
        grass: { base: '#4ade80', highlight: '#65c375', shadow: '#2d5a35' },
        forest: { base: '#16a34a', highlight: '#22c55e', shadow: '#15803d' },
        mountain: { base: '#8b5cf6', highlight: '#a78bfa', shadow: '#6d28d9' },
        water: { base: '#3b82f6', highlight: '#60a5fa', shadow: '#1d4ed8' },
        desert: { base: '#f59e0b', highlight: '#fbbf24', shadow: '#d97706' }
    },
    
    // Initialize the map
    init: function() {
        this.canvas = document.getElementById('gameMap');
        this.ctx = this.canvas.getContext('2d');
        
        // Set up canvas
        this.canvas.width = 800;
        this.canvas.height = 600;
        
        // Calculate tile size to fit the map
        this.tileSize = Math.min(
            this.canvas.width / this.mapSize,
            this.canvas.height / this.mapSize
        );
        
        // Center the viewport on player's city
        if (Game.gameView && Game.gameView.player.city_position) {
            const [cityX, cityY] = Game.gameView.player.city_position;
            this.centerViewport(cityX, cityY);
        }
        
        this.render();
        this.setupMapControls();
    },
    
    // Setup map controls (panning, zooming)
    setupMapControls: function() {
        let isDragging = false;
        let lastMouseX = 0;
        let lastMouseY = 0;
        
        this.canvas.addEventListener('mousedown', (e) => {
            if (e.button === 1 || e.ctrlKey) { // Middle mouse or Ctrl+click for panning
                isDragging = true;
                lastMouseX = e.clientX;
                lastMouseY = e.clientY;
                e.preventDefault();
            }
        });
        
        this.canvas.addEventListener('mousemove', (e) => {
            if (isDragging) {
                const deltaX = e.clientX - lastMouseX;
                const deltaY = e.clientY - lastMouseY;
                
                this.viewportX -= deltaX / this.tileSize;
                this.viewportY -= deltaY / this.tileSize;
                
                this.clampViewport();
                this.render();
                
                lastMouseX = e.clientX;
                lastMouseY = e.clientY;
            }
        });
        
        this.canvas.addEventListener('mouseup', () => {
            isDragging = false;
        });
        
        // Zoom with mouse wheel
        this.canvas.addEventListener('wheel', (e) => {
            e.preventDefault();
            
            const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
            const newTileSize = this.tileSize * zoomFactor;
            
            if (newTileSize >= 8 && newTileSize <= 32) {
                this.tileSize = newTileSize;
                this.render();
            }
        });
    },
    
    // Center viewport on coordinates
    centerViewport: function(x, y) {
        this.viewportX = x - (this.canvas.width / this.tileSize) / 2;
        this.viewportY = y - (this.canvas.height / this.tileSize) / 2;
        this.clampViewport();
    },
    
    // Clamp viewport to map bounds
    clampViewport: function() {
        const maxX = this.mapSize - (this.canvas.width / this.tileSize);
        const maxY = this.mapSize - (this.canvas.height / this.tileSize);
        
        this.viewportX = Math.max(0, Math.min(maxX, this.viewportX));
        this.viewportY = Math.max(0, Math.min(maxY, this.viewportY));
    },
    
    // Update map with new tile data
    updateMap: function(visibleTiles) {
        this.visibleTiles = visibleTiles;
        this.render();
    },
    
    // Render the map
    render: function() {
        // Clear canvas with animated background
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.renderAnimatedBackground();
        
        // Calculate visible tile range
        const startX = Math.floor(this.viewportX);
        const startY = Math.floor(this.viewportY);
        const endX = Math.min(this.mapSize, startX + Math.ceil(this.canvas.width / this.tileSize) + 1);
        const endY = Math.min(this.mapSize, startY + Math.ceil(this.canvas.height / this.tileSize) + 1);
        
        // Render tiles
        for (let x = startX; x < endX; x++) {
            for (let y = startY; y < endY; y++) {
                this.renderTile(x, y);
            }
        }
        
        // Render grid
        this.renderGrid();
        
        // Render player territories
        this.renderTerritories();
        
        // Render buildings
        this.renderBuildings();
        
        // Update particles
        if (window.ParticleSystem) {
            ParticleSystem.update();
        }
    },
    
    // Render animated background
    renderAnimatedBackground: function() {
        const time = Date.now() * 0.001;
        
        // Create animated gradient background
        const gradient = this.ctx.createRadialGradient(
            this.canvas.width * 0.3 + Math.sin(time * 0.5) * 100,
            this.canvas.height * 0.4 + Math.cos(time * 0.3) * 80,
            0,
            this.canvas.width * 0.5,
            this.canvas.height * 0.5,
            Math.sqrt(this.canvas.width * this.canvas.width + this.canvas.height * this.canvas.height) * 0.8
        );
        
        gradient.addColorStop(0, `rgba(26, 35, 50, ${0.9 + Math.sin(time) * 0.1})`);
        gradient.addColorStop(0.5, `rgba(15, 20, 25, ${0.95 + Math.sin(time * 0.7) * 0.05})`);
        gradient.addColorStop(1, 'rgba(10, 15, 20, 1)');
        
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Add subtle stars effect
        this.renderStars(time);
    },
    
    // Render twinkling stars
    renderStars: function(time) {
        const starCount = 50;
        this.ctx.fillStyle = '#ffffff';
        
        for (let i = 0; i < starCount; i++) {
            const x = (i * 17 + 23) % this.canvas.width;
            const y = (i * 31 + 47) % this.canvas.height;
            const twinkle = Math.sin(time + i) * 0.5 + 0.5;
            const alpha = twinkle * 0.3;
            
            this.ctx.globalAlpha = alpha;
            this.ctx.fillRect(x, y, 1, 1);
        }
        
        this.ctx.globalAlpha = 1;
    },
    
    // Render a single tile with enhanced graphics
    renderTile: function(x, y) {
        const screenX = (x - this.viewportX) * this.tileSize;
        const screenY = (y - this.viewportY) * this.tileSize;
        
        // Skip if tile is outside canvas
        if (screenX + this.tileSize < 0 || screenY + this.tileSize < 0 ||
            screenX > this.canvas.width || screenY > this.canvas.height) {
            return;
        }
        
        const tileKey = `${x},${y}`;
        const visibleTiles = Game.gameView ? Game.gameView.visible_tiles : {};
        
        if (visibleTiles[tileKey]) {
            const tile = visibleTiles[tileKey];
            this.renderTerrainWithGradient(screenX, screenY, tile.terrain_type);
            
            // Add resources indicator with glow effect
            if (tile.resources && this.hasResources(tile.resources)) {
                this.renderResourceIndicator(screenX, screenY);
            }
            
            // Add subtle elevation shading
            this.addElevationShading(screenX, screenY, tile.terrain_type);
            
        } else {
            // Unexplored tile with fog of war effect
            this.renderFogOfWar(screenX, screenY);
        }
    },
    
    // Render terrain with gradient effects
    renderTerrainWithGradient: function(screenX, screenY, terrainType) {
        const colors = this.terrainColors[terrainType] || this.terrainColors.grass;
        
        // Create radial gradient for depth
        const gradient = this.ctx.createRadialGradient(
            screenX + this.tileSize * 0.3, screenY + this.tileSize * 0.3, 0,
            screenX + this.tileSize * 0.5, screenY + this.tileSize * 0.5, this.tileSize * 0.7
        );
        
        gradient.addColorStop(0, colors.highlight);
        gradient.addColorStop(0.6, colors.base);
        gradient.addColorStop(1, colors.shadow);
        
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(screenX, screenY, this.tileSize, this.tileSize);
    },
    
    // Add elevation shading for depth
    addElevationShading: function(screenX, screenY, terrainType) {
        if (terrainType === 'mountain') {
            // Add highlight on top-left for mountain peaks
            this.ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
            this.ctx.fillRect(screenX, screenY, this.tileSize * 0.4, this.tileSize * 0.4);
        }
        
        // Add subtle shadow on bottom-right for all tiles
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
        this.ctx.fillRect(
            screenX + this.tileSize * 0.8, 
            screenY + this.tileSize * 0.8, 
            this.tileSize * 0.2, 
            this.tileSize * 0.2
        );
    },
    
    // Render resource indicator with glow
    renderResourceIndicator: function(screenX, screenY) {
        const centerX = screenX + this.tileSize * 0.8;
        const centerY = screenY + this.tileSize * 0.2;
        const radius = this.tileSize * 0.12;
        
        // Glow effect
        this.ctx.shadowColor = '#ffd700';
        this.ctx.shadowBlur = 8;
        
        // Resource gem
        this.ctx.fillStyle = '#ffd700';
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
        this.ctx.fill();
        
        // Inner highlight
        this.ctx.fillStyle = '#ffed4e';
        this.ctx.beginPath();
        this.ctx.arc(centerX - radius * 0.3, centerY - radius * 0.3, radius * 0.4, 0, 2 * Math.PI);
        this.ctx.fill();
        
        // Reset shadow
        this.ctx.shadowBlur = 0;
    },
    
    // Render fog of war with animated effect
    renderFogOfWar: function(screenX, screenY) {
        const time = Date.now() * 0.001;
        const wave = Math.sin(time + screenX * 0.01 + screenY * 0.01) * 0.1 + 0.9;
        
        this.ctx.fillStyle = `rgba(20, 20, 30, ${wave})`;
        this.ctx.fillRect(screenX, screenY, this.tileSize, this.tileSize);
        
        // Add subtle fog pattern
        this.ctx.fillStyle = 'rgba(40, 40, 60, 0.3)';
        this.ctx.fillRect(
            screenX + (this.tileSize * 0.2), 
            screenY + (this.tileSize * 0.2), 
            this.tileSize * 0.6, 
            this.tileSize * 0.6
        );
    },
    
    // Check if tile has resources
    hasResources: function(resources) {
        return Object.values(resources).some(amount => amount > 0);
    },
    
    // Render grid lines
    renderGrid: function() {
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        this.ctx.lineWidth = 1;
        
        const startX = Math.floor(this.viewportX);
        const startY = Math.floor(this.viewportY);
        const endX = Math.min(this.mapSize, startX + Math.ceil(this.canvas.width / this.tileSize) + 1);
        const endY = Math.min(this.mapSize, startY + Math.ceil(this.canvas.height / this.tileSize) + 1);
        
        // Vertical lines
        for (let x = startX; x <= endX; x++) {
            const screenX = (x - this.viewportX) * this.tileSize;
            this.ctx.beginPath();
            this.ctx.moveTo(screenX, 0);
            this.ctx.lineTo(screenX, this.canvas.height);
            this.ctx.stroke();
        }
        
        // Horizontal lines
        for (let y = startY; y <= endY; y++) {
            const screenY = (y - this.viewportY) * this.tileSize;
            this.ctx.beginPath();
            this.ctx.moveTo(0, screenY);
            this.ctx.lineTo(this.canvas.width, screenY);
            this.ctx.stroke();
        }
    },
    
    // Render territory borders with glow effects
    renderTerritories: function() {
        if (!Game.gameView) return;
        
        const visibleTiles = Game.gameView.visible_tiles;
        const playerId = Game.gameView.player.player_id;
        const time = Date.now() * 0.003;
        
        this.ctx.lineWidth = 3;
        
        for (const [tileKey, tile] of Object.entries(visibleTiles)) {
            if (tile.owner) {
                const screenX = (tile.x - this.viewportX) * this.tileSize;
                const screenY = (tile.y - this.viewportY) * this.tileSize;
                
                // Skip if tile is outside canvas
                if (screenX + this.tileSize < 0 || screenY + this.tileSize < 0 ||
                    screenX > this.canvas.width || screenY > this.canvas.height) {
                    continue;
                }
                
                // Animated glow effect
                const glowIntensity = Math.sin(time + tile.x * 0.1 + tile.y * 0.1) * 0.3 + 0.7;
                
                // Set border color and glow based on owner
                if (tile.owner === playerId) {
                    this.ctx.shadowColor = '#3b82f6';
                    this.ctx.shadowBlur = 8 * glowIntensity;
                    this.ctx.strokeStyle = `rgba(59, 130, 246, ${glowIntensity})`;
                } else {
                    this.ctx.shadowColor = '#ef4444';
                    this.ctx.shadowBlur = 6 * glowIntensity;
                    this.ctx.strokeStyle = `rgba(239, 68, 68, ${glowIntensity})`;
                }
                
                this.ctx.strokeRect(screenX + 1, screenY + 1, this.tileSize - 2, this.tileSize - 2);
                
                // Add corner highlights
                this.renderCornerHighlights(screenX, screenY, tile.owner === playerId);
            }
        }
        
        // Reset shadow
        this.ctx.shadowBlur = 0;
    },
    
    // Add corner highlights for owned territories
    renderCornerHighlights: function(screenX, screenY, isPlayer) {
        const cornerSize = this.tileSize * 0.15;
        const color = isPlayer ? 'rgba(59, 130, 246, 0.8)' : 'rgba(239, 68, 68, 0.8)';
        
        this.ctx.fillStyle = color;
        
        // Top-left corner
        this.ctx.fillRect(screenX, screenY, cornerSize, cornerSize);
        // Top-right corner
        this.ctx.fillRect(screenX + this.tileSize - cornerSize, screenY, cornerSize, cornerSize);
        // Bottom-left corner
        this.ctx.fillRect(screenX, screenY + this.tileSize - cornerSize, cornerSize, cornerSize);
        // Bottom-right corner
        this.ctx.fillRect(screenX + this.tileSize - cornerSize, screenY + this.tileSize - cornerSize, cornerSize, cornerSize);
    },
    
    // Render buildings
    renderBuildings: function() {
        if (!Game.gameView) return;
        
        const visibleTiles = Game.gameView.visible_tiles;
        
        for (const [tileKey, tile] of Object.entries(visibleTiles)) {
            if (tile.building) {
                const screenX = (tile.x - this.viewportX) * this.tileSize;
                const screenY = (tile.y - this.viewportY) * this.tileSize;
                
                // Skip if tile is outside canvas
                if (screenX + this.tileSize < 0 || screenY + this.tileSize < 0 ||
                    screenX > this.canvas.width || screenY > this.canvas.height) {
                    continue;
                }
                
                this.renderBuilding(screenX, screenY, tile.building);
            }
        }
    },
    
    // Render enhanced buildings with 3D effects
    renderBuilding: function(screenX, screenY, buildingType) {
        const centerX = screenX + this.tileSize / 2;
        const centerY = screenY + this.tileSize / 2;
        const size = this.tileSize * 0.7;
        
        if (buildingType === 'city') {
            this.renderCity(centerX, centerY, size);
        } else {
            this.renderGenericBuilding(centerX, centerY, size, buildingType);
        }
    },
    
    // Render city with detailed graphics
    renderCity: function(centerX, centerY, size) {
        // Main castle base with gradient
        const gradient = this.ctx.createLinearGradient(
            centerX - size/2, centerY - size/2,
            centerX + size/2, centerY + size/2
        );
        gradient.addColorStop(0, '#8b4513');
        gradient.addColorStop(0.5, '#d2691e');
        gradient.addColorStop(1, '#654321');
        
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(centerX - size/2, centerY - size/2, size, size);
        
        // Add towers with height effect
        const towerSize = size * 0.25;
        this.ctx.fillStyle = '#a0522d';
        
        // Four corner towers
        this.ctx.fillRect(centerX - size/2 - towerSize/2, centerY - size/2 - towerSize, towerSize, towerSize * 1.5);
        this.ctx.fillRect(centerX + size/2 - towerSize/2, centerY - size/2 - towerSize, towerSize, towerSize * 1.5);
        this.ctx.fillRect(centerX - size/2 - towerSize/2, centerY + size/2 - towerSize/2, towerSize, towerSize * 1.2);
        this.ctx.fillRect(centerX + size/2 - towerSize/2, centerY + size/2 - towerSize/2, towerSize, towerSize * 1.2);
        
        // Add flags on towers
        this.ctx.fillStyle = '#ff4444';
        this.ctx.fillRect(centerX - size/2, centerY - size/2 - towerSize, towerSize * 0.6, towerSize * 0.3);
        this.ctx.fillRect(centerX + size/2 - towerSize * 0.6, centerY - size/2 - towerSize, towerSize * 0.6, towerSize * 0.3);
        
        // Add glow effect around city
        this.ctx.shadowColor = '#ffd700';
        this.ctx.shadowBlur = 12;
        this.ctx.strokeStyle = '#ffd700';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(centerX - size/2 - 2, centerY - size/2 - 2, size + 4, size + 4);
        this.ctx.shadowBlur = 0;
    },
    
    // Render generic building with type-specific styling
    renderGenericBuilding: function(centerX, centerY, size, buildingType) {
        // Building colors based on type
        const buildingColors = {
            'farm': { base: '#8fbc8f', roof: '#654321' },
            'mine': { base: '#696969', roof: '#2f4f4f' },
            'barrack': { base: '#4682b4', roof: '#191970' },
            'default': { base: '#d2691e', roof: '#8b4513' }
        };
        
        const colors = buildingColors[buildingType] || buildingColors.default;
        
        // Building base with 3D effect
        this.ctx.fillStyle = colors.base;
        this.ctx.fillRect(centerX - size/2, centerY - size/2, size, size * 0.8);
        
        // Roof with perspective
        this.ctx.fillStyle = colors.roof;
        this.ctx.beginPath();
        this.ctx.moveTo(centerX - size/2, centerY - size/2);
        this.ctx.lineTo(centerX, centerY - size/2 - size * 0.3);
        this.ctx.lineTo(centerX + size/2, centerY - size/2);
        this.ctx.lineTo(centerX + size/2, centerY - size/2 + size * 0.2);
        this.ctx.lineTo(centerX, centerY - size/2 + size * 0.2 - size * 0.3);
        this.ctx.lineTo(centerX - size/2, centerY - size/2 + size * 0.2);
        this.ctx.closePath();
        this.ctx.fill();
        
        // Add windows/details
        this.ctx.fillStyle = '#fff8dc';
        this.ctx.fillRect(centerX - size * 0.15, centerY - size * 0.1, size * 0.1, size * 0.15);
        this.ctx.fillRect(centerX + size * 0.05, centerY - size * 0.1, size * 0.1, size * 0.15);
        
        // Door
        this.ctx.fillStyle = '#654321';
        this.ctx.fillRect(centerX - size * 0.08, centerY + size * 0.1, size * 0.16, size * 0.3);
    }
};

// Export for use in other files
window.GameMap = GameMap;
