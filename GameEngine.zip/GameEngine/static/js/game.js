// Main Game Controller
const Game = {
    // Game state
    gameView: null,
    selectedTile: null,
    
    // Initialize the game
    init: function(initialGameView) {
        this.gameView = initialGameView;
        this.setupEventListeners();
        this.startGameLoop();
        GameMap.init();
        ParticleSystem.init();
        UI.init();
        
        console.log('Game initialized');
    },
    
    // Set up event listeners
    setupEventListeners: function() {
        // Building upgrade buttons
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('upgrade-building')) {
                const buildingName = e.target.getAttribute('data-building');
                this.upgradeBuilding(buildingName);
            }
        });
        
        // Troop training buttons
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('train-troops')) {
                const troopType = e.target.getAttribute('data-type');
                const quantity = parseInt(e.target.getAttribute('data-qty'));
                this.trainTroops(troopType, quantity);
            }
        });
        
        // Map click events
        document.getElementById('gameMap').addEventListener('click', (e) => {
            const rect = e.target.getBoundingClientRect();
            const x = Math.floor((e.clientX - rect.left) / GameMap.tileSize);
            const y = Math.floor((e.clientY - rect.top) / GameMap.tileSize);
            this.handleTileClick(x, y);
        });
        
        // Map hover events
        document.getElementById('gameMap').addEventListener('mousemove', (e) => {
            const rect = e.target.getBoundingClientRect();
            const x = Math.floor((e.clientX - rect.left) / GameMap.tileSize);
            const y = Math.floor((e.clientY - rect.top) / GameMap.tileSize);
            this.handleTileHover(x, y, e.clientX, e.clientY);
        });
        
        document.getElementById('gameMap').addEventListener('mouseleave', () => {
            UI.hideTooltip();
        });
    },
    
    // Start the game update loop
    startGameLoop: function() {
        // Update game state every 30 seconds
        setInterval(() => {
            this.updateGameState();
        }, 30000);
        
        // Update UI every 5 seconds
        setInterval(() => {
            this.updateUI();
        }, 5000);
    },
    
    // Update game state from server
    updateGameState: function() {
        fetch('/get_game_state')
            .then(response => response.json())
            .then(data => {
                if (data.game_view) {
                    this.gameView = data.game_view;
                    GameMap.updateMap(data.game_view.visible_tiles);
                    ParticleSystem.update();
                    UI.updateResources(data.game_view.player.resources);
                    UI.updateBuildings(data.game_view.player.buildings);
                    UI.updateTroops(data.game_view.player.troops);
                    UI.updateTick(data.game_view.current_tick);
                }
                
                if (data.leaderboard) {
                    UI.updateLeaderboard(data.leaderboard);
                }
            })
            .catch(error => {
                console.error('Error updating game state:', error);
            });
    },
    
    // Update UI elements
    updateUI: function() {
        if (this.gameView) {
            UI.updateTrainingQueue(this.gameView.player.training_queue);
            UI.updateBuildingStates(this.gameView.player.buildings, this.gameView.current_tick);
        }
    },
    
    // Handle tile clicks
    handleTileClick: function(x, y) {
        if (x < 0 || y < 0 || x >= 50 || y >= 50) return;
        
        fetch(`/get_tile_info/${x}/${y}`)
            .then(response => response.json())
            .then(data => {
                if (data.tile) {
                    this.selectedTile = {x, y, data: data.tile};
                    this.showTileActions(x, y, data.tile);
                } else {
                    UI.showMessage('Tile not visible', 'warning');
                }
            })
            .catch(error => {
                console.error('Error getting tile info:', error);
            });
    },
    
    // Handle tile hover
    handleTileHover: function(x, y, mouseX, mouseY) {
        if (x < 0 || y < 0 || x >= 50 || y >= 50) {
            UI.hideTooltip();
            return;
        }
        
        const tileKey = `${x},${y}`;
        const visibleTiles = this.gameView.visible_tiles;
        
        if (visibleTiles[tileKey]) {
            const tile = visibleTiles[tileKey];
            UI.showTooltip(mouseX, mouseY, this.formatTileTooltip(tile));
        } else {
            UI.showTooltip(mouseX, mouseY, 'Unexplored Territory');
        }
    },
    
    // Format tile tooltip content
    formatTileTooltip: function(tile) {
        let content = `<strong>${tile.terrain_type.charAt(0).toUpperCase() + tile.terrain_type.slice(1)}</strong><br>`;
        content += `Position: (${tile.x}, ${tile.y})<br>`;
        
        if (tile.owner) {
            const owner = this.getPlayerName(tile.owner);
            content += `Owner: ${owner}<br>`;
        } else {
            content += 'Neutral Territory<br>';
        }
        
        if (tile.building) {
            content += `Building: ${tile.building}<br>`;
        }
        
        if (tile.resources) {
            const resources = [];
            for (const [type, amount] of Object.entries(tile.resources)) {
                if (amount > 0) {
                    resources.push(`${type}: ${amount}`);
                }
            }
            if (resources.length > 0) {
                content += `Resources: ${resources.join(', ')}`;
            }
        }
        
        return content;
    },
    
    // Get player name by ID
    getPlayerName: function(playerId) {
        // This would need to be expanded with actual player data
        if (playerId === this.gameView.player.player_id) {
            return 'You';
        }
        return `Player ${playerId}`;
    },
    
    // Show tile action modal
    showTileActions: function(x, y, tile) {
        const modal = new bootstrap.Modal(document.getElementById('actionModal'));
        const modalTitle = document.getElementById('actionModalTitle');
        const modalBody = document.getElementById('actionModalBody');
        
        modalTitle.textContent = `Tile (${x}, ${y}) - ${tile.terrain_type}`;
        
        let content = `<div class="tile-info mb-3">`;
        content += `<p><strong>Terrain:</strong> ${tile.terrain_type}</p>`;
        
        if (tile.owner) {
            content += `<p><strong>Owner:</strong> ${this.getPlayerName(tile.owner)}</p>`;
        }
        
        if (tile.building) {
            content += `<p><strong>Building:</strong> ${tile.building}</p>`;
        }
        
        content += `</div>`;
        
        // Add action buttons
        content += `<div class="tile-actions">`;
        
        if (tile.can_attack) {
            content += `<button class="btn btn-danger me-2" onclick="Game.attackTile(${x}, ${y})">
                <i data-feather="sword"></i> Attack
            </button>`;
        }
        
        if (tile.owner === this.gameView.player.player_id) {
            content += `<button class="btn btn-success" onclick="Game.gatherResources(${x}, ${y})">
                <i data-feather="package"></i> Gather Resources
            </button>`;
        }
        
        content += `</div>`;
        
        modalBody.innerHTML = content;
        feather.replace();
        modal.show();
    },
    
    // Upgrade building
    upgradeBuilding: function(buildingName) {
        UI.setLoading(true);
        
        fetch('/upgrade_building', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                building_name: buildingName
            })
        })
        .then(response => response.json())
        .then(data => {
            UI.setLoading(false);
            
            if (data.success) {
                UI.showMessage(data.message, 'success');
                this.updateGameState();
            } else {
                UI.showMessage(data.message, 'danger');
            }
        })
        .catch(error => {
            UI.setLoading(false);
            console.error('Error upgrading building:', error);
            UI.showMessage('Failed to upgrade building', 'danger');
        });
    },
    
    // Train troops
    trainTroops: function(troopType, quantity) {
        UI.setLoading(true);
        
        fetch('/train_troops', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                troop_type: troopType,
                quantity: quantity
            })
        })
        .then(response => response.json())
        .then(data => {
            UI.setLoading(false);
            
            if (data.success) {
                UI.showMessage(data.message, 'success');
                this.updateGameState();
            } else {
                UI.showMessage(data.message, 'danger');
            }
        })
        .catch(error => {
            UI.setLoading(false);
            console.error('Error training troops:', error);
            UI.showMessage('Failed to train troops', 'danger');
        });
    },
    
    // Attack tile
    attackTile: function(x, y) {
        if (!confirm('Are you sure you want to attack this tile?')) {
            return;
        }
        
        UI.setLoading(true);
        
        fetch('/attack_tile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                x: x,
                y: y
            })
        })
        .then(response => response.json())
        .then(data => {
            UI.setLoading(false);
            
            if (data.success) {
                const result = data.battle_result;
                let message = `Battle completed! ${result.winner} won.\n`;
                message += `Your losses: ${JSON.stringify(result.attacker_losses)}\n`;
                message += `Enemy losses: ${JSON.stringify(result.defender_losses)}`;
                
                UI.showMessage(message, result.winner === 'attacker' ? 'success' : 'warning');
                this.updateGameState();
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('actionModal'));
                if (modal) {
                    modal.hide();
                }
            } else {
                UI.showMessage(data.message, 'danger');
            }
        })
        .catch(error => {
            UI.setLoading(false);
            console.error('Error attacking tile:', error);
            UI.showMessage('Failed to attack tile', 'danger');
        });
    },
    
    // Gather resources (placeholder)
    gatherResources: function(x, y) {
        UI.showMessage('Resource gathering will be implemented in a future update', 'info');
    },
    
    // Recruit hero
    recruitHero: function(heroId) {
        const data = { hero_id: heroId };
        
        fetch('/recruit_hero', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            UI.showMessage(data.message, data.success ? 'success' : 'error');
            if (data.success) {
                this.updateGameState();
            }
        })
        .catch(error => {
            console.error('Error recruiting hero:', error);
            UI.showMessage('Error recruiting hero', 'error');
        });
    }
};

// Export for use in other files
window.Game = Game;
