"""
Hero system for Eclipse of Empires
Based on Kingshot-style hero mechanics with different rarities and unit types
"""

from typing import Dict, List, Any
import random

class HeroSystem:
    """Manages heroes, recruitment, and battle mechanics"""
    
    # Hero data based on Kingshot structure
    HEROES = {
        # Epic Heroes (5-star)
        'diana': {
            'name': 'Diana',
            'type': 'archer',
            'rarity': 'epic',
            'stars': 5,
            'attack': 120,
            'defense': 80,
            'health': 800,
            'skills': ['precision_shot', 'eagle_eye'],
            'cost': {'gold': 10000, 'gems': 500}
        },
        'gordon': {
            'name': 'Gordon',
            'type': 'cavalry',
            'rarity': 'epic',
            'stars': 5,
            'attack': 140,
            'defense': 100,
            'health': 1000,
            'skills': ['charge', 'battle_fury'],
            'cost': {'gold': 12000, 'gems': 600}
        },
        'howard': {
            'name': 'Howard',
            'type': 'infantry',
            'rarity': 'epic',
            'stars': 5,
            'attack': 100,
            'defense': 150,
            'health': 1200,
            'skills': ['shield_wall', 'fortress'],
            'cost': {'gold': 11000, 'gems': 550}
        },
        
        # Generation 3 Heroes (4-star)
        'jaeger': {
            'name': 'Jaeger',
            'type': 'archer',
            'rarity': 'legendary',
            'stars': 4,
            'attack': 100,
            'defense': 70,
            'health': 700,
            'skills': ['multi_shot', 'hunter_mark'],
            'cost': {'gold': 8000, 'gems': 300}
        },
        'eric': {
            'name': 'Eric',
            'type': 'infantry',
            'rarity': 'legendary',
            'stars': 4,
            'attack': 90,
            'defense': 120,
            'health': 900,
            'skills': ['berserker', 'iron_will'],
            'cost': {'gold': 8500, 'gems': 350}
        },
        'petra': {
            'name': 'Petra',
            'type': 'cavalry',
            'rarity': 'legendary',
            'stars': 4,
            'attack': 110,
            'defense': 85,
            'health': 850,
            'skills': ['lightning_strike', 'tactical_retreat'],
            'cost': {'gold': 9000, 'gems': 400}
        },
        
        # Generation 2 Heroes (3-star)
        'hilde': {
            'name': 'Hilde',
            'type': 'cavalry',
            'rarity': 'rare',
            'stars': 3,
            'attack': 85,
            'defense': 75,
            'health': 650,
            'skills': ['cavalry_charge'],
            'cost': {'gold': 5000, 'gems': 150}
        },
        'zoe': {
            'name': 'Zoe',
            'type': 'infantry',
            'rarity': 'rare',
            'stars': 3,
            'attack': 80,
            'defense': 90,
            'health': 700,
            'skills': ['defensive_stance'],
            'cost': {'gold': 4500, 'gems': 120}
        },
        'marlin': {
            'name': 'Marlin',
            'type': 'archer',
            'rarity': 'rare',
            'stars': 3,
            'attack': 90,
            'defense': 60,
            'health': 600,
            'skills': ['aimed_shot'],
            'cost': {'gold': 4800, 'gems': 130}
        },
        
        # Generation 1 Heroes (2-star)
        'jabel': {
            'name': 'Jabel',
            'type': 'cavalry',
            'rarity': 'common',
            'stars': 2,
            'attack': 70,
            'defense': 65,
            'health': 550,
            'skills': ['mounted_combat'],
            'cost': {'gold': 2000, 'gems': 50}
        },
        'amadeus': {
            'name': 'Amadeus',
            'type': 'infantry',
            'rarity': 'common',
            'stars': 2,
            'attack': 65,
            'defense': 80,
            'health': 600,
            'skills': ['sword_mastery'],
            'cost': {'gold': 1800, 'gems': 40}
        },
        'helga': {
            'name': 'Helga',
            'type': 'infantry',
            'rarity': 'common',
            'stars': 2,
            'attack': 70,
            'defense': 75,
            'health': 580,
            'skills': ['battle_cry'],
            'cost': {'gold': 1900, 'gems': 45}
        },
        'saul': {
            'name': 'Saul',
            'type': 'archer',
            'rarity': 'common',
            'stars': 2,
            'attack': 75,
            'defense': 55,
            'health': 500,
            'skills': ['rapid_fire'],
            'cost': {'gold': 2100, 'gems': 55}
        }
    }
    
    @staticmethod
    def get_available_heroes() -> Dict[str, Dict[str, Any]]:
        """Get all available heroes"""
        return HeroSystem.HEROES.copy()
    
    @staticmethod
    def get_hero_by_id(hero_id: str) -> Dict[str, Any]:
        """Get hero data by ID"""
        return HeroSystem.HEROES.get(hero_id, {})
    
    @staticmethod
    def get_heroes_by_type(unit_type: str) -> List[Dict[str, Any]]:
        """Get all heroes of a specific type"""
        return [
            {**hero, 'id': hero_id} 
            for hero_id, hero in HeroSystem.HEROES.items() 
            if hero['type'] == unit_type
        ]
    
    @staticmethod
    def get_heroes_by_rarity(rarity: str) -> List[Dict[str, Any]]:
        """Get all heroes of a specific rarity"""
        return [
            {**hero, 'id': hero_id} 
            for hero_id, hero in HeroSystem.HEROES.items() 
            if hero['rarity'] == rarity
        ]
    
    @staticmethod
    def can_recruit_hero(player_resources: Dict[str, int], hero_id: str) -> bool:
        """Check if player can afford to recruit a hero"""
        hero = HeroSystem.get_hero_by_id(hero_id)
        if not hero:
            return False
        
        cost = hero.get('cost', {})
        for resource, amount in cost.items():
            if player_resources.get(resource, 0) < amount:
                return False
        
        return True
    
    @staticmethod
    def recruit_hero(player_data: Dict[str, Any], hero_id: str) -> bool:
        """Recruit a hero for the player"""
        hero = HeroSystem.get_hero_by_id(hero_id)
        if not hero:
            return False
        
        # Check if player can afford
        if not HeroSystem.can_recruit_hero(player_data.get('resources', {}), hero_id):
            return False
        
        # Deduct costs
        cost = hero.get('cost', {})
        resources = player_data.get('resources', {})
        for resource, amount in cost.items():
            resources[resource] = resources.get(resource, 0) - amount
        
        # Add hero to player's collection
        if 'heroes' not in player_data:
            player_data['heroes'] = {}
        
        player_data['heroes'][hero_id] = {
            'level': 1,
            'experience': 0,
            'recruited_at': 'current_tick'  # Would use actual tick in game
        }
        
        return True
    
    @staticmethod
    def calculate_army_strength(heroes: Dict[str, Any], troops: Dict[str, int]) -> int:
        """Calculate total army strength including hero bonuses"""
        base_strength = sum(troops.values())
        hero_bonus = 0
        
        for hero_id, hero_data in heroes.items():
            hero = HeroSystem.get_hero_by_id(hero_id)
            if hero:
                level = hero_data.get('level', 1)
                # Heroes provide percentage bonus to their unit type
                unit_type = hero['type']
                if unit_type in troops:
                    type_troops = troops[unit_type] if unit_type != 'archer' else troops.get('archers', 0)
                    hero_bonus += int(type_troops * (hero['attack'] / 100) * level * 0.1)
        
        return base_strength + hero_bonus