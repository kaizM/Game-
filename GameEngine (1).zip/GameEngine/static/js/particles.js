// Particle effects and animations system
class ParticleSystem {
    constructor() {
        this.particles = [];
        this.effects = new Map();
        this.canvas = null;
        this.ctx = null;
        this.animationId = null;
        this.isRunning = false;
        
        this.init();
    }
    
    init() {
        this.createCanvas();
        this.setupEffectTemplates();
        this.start();
    }
    
    createCanvas() {
        // Create overlay canvas for particle effects
        this.canvas = document.createElement('canvas');
        this.canvas.id = 'particle-canvas';
        this.canvas.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 5000;
        `;
        
        document.body.appendChild(this.canvas);
        this.ctx = this.canvas.getContext('2d');
        
        // Resize canvas to match window
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
    }
    
    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }
    
    setupEffectTemplates() {
        // Battle effect
        this.effects.set('battle', {
            particleCount: 20,
            duration: 2000,
            particles: {
                color: ['#e74c3c', '#f39c12', '#ffffff'],
                size: { min: 2, max: 6 },
                speed: { min: 50, max: 150 },
                life: { min: 1000, max: 2000 },
                gravity: 0.3,
                spread: Math.PI * 2
            }
        });
        
        // Build effect
        this.effects.set('build', {
            particleCount: 15,
            duration: 1500,
            particles: {
                color: ['#f1c40f', '#e67e22', '#d35400'],
                size: { min: 1, max: 4 },
                speed: { min: 30, max: 100 },
                life: { min: 800, max: 1500 },
                gravity: -0.2,
                spread: Math.PI / 3
            }
        });
        
        // Resource gain effect
        this.effects.set('resource_gain', {
            particleCount: 10,
            duration: 1000,
            particles: {
                color: ['#27ae60', '#2ecc71', '#f1c40f'],
                size: { min: 2, max: 5 },
                speed: { min: 20, max: 80 },
                life: { min: 600, max: 1000 },
                gravity: -0.5,
                spread: Math.PI / 4
            }
        });
        
        // Troop movement effect
        this.effects.set('move', {
            particleCount: 8,
            duration: 1000,
            particles: {
                color: ['#3498db', '#74b9ff', '#ffffff'],
                size: { min: 1, max: 3 },
                speed: { min: 40, max: 120 },
                life: { min: 500, max: 1000 },
                gravity: 0.1,
                spread: Math.PI / 6
            }
        });
        
        // Magic/hero effect
        this.effects.set('magic', {
            particleCount: 25,
            duration: 2500,
            particles: {
                color: ['#9b59b6', '#8e44ad', '#ffffff', '#f1c40f'],
                size: { min: 1, max: 5 },
                speed: { min: 20, max: 100 },
                life: { min: 1000, max: 2000 },
                gravity: -0.1,
                spread: Math.PI * 2
            }
        });
        
        // Destruction effect
        this.effects.set('destroy', {
            particleCount: 30,
            duration: 2000,
            particles: {
                color: ['#e74c3c', '#c0392b', '#34495e', '#95a5a6'],
                size: { min: 2, max: 8 },
                speed: { min: 80, max: 200 },
                life: { min: 800, max: 1800 },
                gravity: 0.5,
                spread: Math.PI * 2
            }
        });
    }
    
    start() {
        if (!this.isRunning) {
            this.isRunning = true;
            this.animate();
        }
    }
    
    stop() {
        this.isRunning = false;
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
    }
    
    animate() {
        if (!this.isRunning) return;
        
        this.update();
        this.render();
        
        this.animationId = requestAnimationFrame(() => this.animate());
    }
    
    update() {
        const now = Date.now();
        
        // Update existing particles
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const particle = this.particles[i];
            
            // Check if particle is dead
            if (now - particle.birth > particle.life) {
                this.particles.splice(i, 1);
                continue;
            }
            
            // Update position
            particle.x += particle.vx * 0.016; // 60fps normalization
            particle.y += particle.vy * 0.016;
            
            // Apply gravity
            particle.vy += particle.gravity;
            
            // Update alpha based on age
            const age = (now - particle.birth) / particle.life;
            particle.alpha = Math.max(0, 1 - age);
            
            // Update size
            particle.currentSize = particle.size * (1 - age * 0.5);
        }
    }
    
    render() {
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Render particles
        this.particles.forEach(particle => {
            this.ctx.save();
            
            this.ctx.globalAlpha = particle.alpha;
            this.ctx.fillStyle = particle.color;
            
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.currentSize, 0, Math.PI * 2);
            this.ctx.fill();
            
            this.ctx.restore();
        });
    }
    
    createEffect(effectType, x, y, options = {}) {
        const template = this.effects.get(effectType);
        if (!template) {
            console.warn(`Unknown effect type: ${effectType}`);
            return;
        }
        
        // Convert screen coordinates if needed
        const screenPos = this.worldToScreen(x, y);
        
        const config = { ...template, ...options };
        const now = Date.now();
        
        for (let i = 0; i < config.particleCount; i++) {
            this.particles.push(this.createParticle(screenPos.x, screenPos.y, config.particles, now));
        }
    }
    
    createParticle(x, y, config, birth) {
        const angle = Math.random() * config.spread - config.spread / 2;
        const speed = this.randomBetween(config.speed.min, config.speed.max);
        
        return {
            x: x + this.randomBetween(-10, 10),
            y: y + this.randomBetween(-10, 10),
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            size: this.randomBetween(config.size.min, config.size.max),
            currentSize: 0,
            color: this.randomChoice(config.color),
            life: this.randomBetween(config.life.min, config.life.max),
            birth: birth,
            alpha: 1,
            gravity: config.gravity || 0
        };
    }
    
    worldToScreen(x, y) {
        // Convert game world coordinates to screen coordinates
        // This would need to be implemented based on your map coordinate system
        const mapGrid = document.getElementById('map-grid');
        if (!mapGrid) return { x, y };
        
        const tile = mapGrid.querySelector(`[data-x="${x}"][data-y="${y}"]`);
        if (tile) {
            const rect = tile.getBoundingClientRect();
            return {
                x: rect.left + rect.width / 2,
                y: rect.top + rect.height / 2
            };
        }
        
        return { x, y };
    }
    
    randomBetween(min, max) {
        return Math.random() * (max - min) + min;
    }
    
    randomChoice(array) {
        return array[Math.floor(Math.random() * array.length)];
    }
    
    // Public methods for triggering effects
    
    battleEffect(x, y) {
        this.createEffect('battle', x, y);
        
        // Add camera shake
        this.cameraShake(300, 5);
    }
    
    buildEffect(x, y) {
        this.createEffect('build', x, y);
    }
    
    resourceGainEffect(x, y) {
        this.createEffect('resource_gain', x, y);
    }
    
    moveEffect(fromX, fromY, toX, toY) {
        // Create trail effect
        this.createMovementTrail(fromX, fromY, toX, toY);
        this.createEffect('move', toX, toY);
    }
    
    magicEffect(x, y) {
        this.createEffect('magic', x, y);
    }
    
    destroyEffect(x, y) {
        this.createEffect('destroy', x, y);
        this.cameraShake(500, 8);
    }
    
    createMovementTrail(fromX, fromY, toX, toY) {
        const steps = 10;
        const delay = 50;
        
        for (let i = 0; i <= steps; i++) {
            const progress = i / steps;
            const x = fromX + (toX - fromX) * progress;
            const y = fromY + (toY - fromY) * progress;
            
            setTimeout(() => {
                this.createEffect('move', x, y, { particleCount: 3 });
            }, delay * i);
        }
    }
    
    cameraShake(duration, intensity) {
        const gameContainer = document.querySelector('.game-container');
        if (!gameContainer) return;
        
        const startTime = Date.now();
        const originalTransform = gameContainer.style.transform;
        
        const shake = () => {
            const elapsed = Date.now() - startTime;
            if (elapsed > duration) {
                gameContainer.style.transform = originalTransform;
                return;
            }
            
            const progress = elapsed / duration;
            const currentIntensity = intensity * (1 - progress);
            
            const x = (Math.random() - 0.5) * currentIntensity;
            const y = (Math.random() - 0.5) * currentIntensity;
            
            gameContainer.style.transform = `translate(${x}px, ${y}px) ${originalTransform}`;
            
            requestAnimationFrame(shake);
        };
        
        shake();
    }
    
    // Screen flash effect
    screenFlash(color = '#ffffff', duration = 200, opacity = 0.3) {
        const flash = document.createElement('div');
        flash.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: ${color};
            opacity: ${opacity};
            z-index: 9998;
            pointer-events: none;
            animation: flashFade ${duration}ms ease-out;
        `;
        
        // Add CSS animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes flashFade {
                0% { opacity: ${opacity}; }
                100% { opacity: 0; }
            }
        `;
        document.head.appendChild(style);
        
        document.body.appendChild(flash);
        
        setTimeout(() => {
            flash.remove();
            style.remove();
        }, duration);
    }
    
    // Weather effects
    createRain() {
        const rainEffect = {
            particleCount: 100,
            duration: 60000, // 1 minute
            particles: {
                color: ['#3498db', '#74b9ff'],
                size: { min: 1, max: 2 },
                speed: { min: 200, max: 400 },
                life: { min: 2000, max: 4000 },
                gravity: 0.8,
                spread: Math.PI / 8
            }
        };
        
        // Create rain at top of screen
        for (let i = 0; i < 50; i++) {
            setTimeout(() => {
                this.createEffect('rain', Math.random() * window.innerWidth, -20, rainEffect);
            }, i * 100);
        }
    }
    
    createSnow() {
        const snowEffect = {
            particleCount: 60,
            duration: 60000,
            particles: {
                color: ['#ffffff', '#ecf0f1'],
                size: { min: 2, max: 6 },
                speed: { min: 20, max: 60 },
                life: { min: 5000, max: 10000 },
                gravity: 0.1,
                spread: Math.PI / 4
            }
        };
        
        // Create snow at top of screen
        for (let i = 0; i < 30; i++) {
            setTimeout(() => {
                this.createEffect('snow', Math.random() * window.innerWidth, -20, snowEffect);
            }, i * 200);
        }
    }
    
    // Resource collection animation
    animateResourceCollection(fromElement, toElement, resourceType, amount) {
        if (!fromElement || !toElement) return;
        
        const fromRect = fromElement.getBoundingClientRect();
        const toRect = toElement.getBoundingClientRect();
        
        const resourceIcon = document.createElement('div');
        resourceIcon.style.cssText = `
            position: fixed;
            left: ${fromRect.left + fromRect.width / 2}px;
            top: ${fromRect.top + fromRect.height / 2}px;
            font-size: 16px;
            z-index: 6000;
            pointer-events: none;
            transition: all 1s ease-in-out;
        `;
        
        const icons = {
            gold: '💰',
            food: '🍞',
            wood: '🌳',
            stone: '🗿'
        };
        
        resourceIcon.innerHTML = `${icons[resourceType] || '💎'} +${amount}`;
        document.body.appendChild(resourceIcon);
        
        // Animate to target
        setTimeout(() => {
            resourceIcon.style.left = toRect.left + toRect.width / 2 + 'px';
            resourceIcon.style.top = toRect.top + toRect.height / 2 + 'px';
            resourceIcon.style.opacity = '0';
            resourceIcon.style.transform = 'scale(0.5)';
        }, 50);
        
        // Remove after animation
        setTimeout(() => {
            resourceIcon.remove();
        }, 1050);
        
        // Create particle effect at destination
        setTimeout(() => {
            this.resourceGainEffect(
                toRect.left + toRect.width / 2,
                toRect.top + toRect.height / 2
            );
        }, 1000);
    }
    
    // Clean up
    destroy() {
        this.stop();
        if (this.canvas) {
            this.canvas.remove();
        }
        this.particles = [];
    }
}

// Initialize particle system
document.addEventListener('DOMContentLoaded', () => {
    window.particleSystem = new ParticleSystem();
    
    // Add particle system to game manager when available
    setTimeout(() => {
        if (window.gameManager) {
            window.gameManager.particleSystem = window.particleSystem;
        }
    }, 200);
});

// Clean up on page unload
window.addEventListener('beforeunload', () => {
    if (window.particleSystem) {
        window.particleSystem.destroy();
    }
});
