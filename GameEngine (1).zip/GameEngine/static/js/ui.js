// UI management and interactive components
class UIManager {
    constructor(gameManager) {
        this.gameManager = gameManager;
        this.modals = new Map();
        this.notifications = [];
        this.actionMode = null;
        this.selectedTroops = new Map();
        
        this.init();
    }
    
    init() {
        this.setupModals();
        this.setupNotificationSystem();
        this.setupKeyboardShortcuts();
        this.setupTooltips();
        this.setupContextMenus();
        this.setupAnimations();
    }
    
    setupModals() {
        // Initialize Bootstrap modals
        const modalElements = document.querySelectorAll('.modal');
        modalElements.forEach(modalEl => {
            const modal = new bootstrap.Modal(modalEl);
            this.modals.set(modalEl.id, modal);
        });
        
        // Custom modal event handlers
        this.setupBuildModalHandlers();
        this.setupTrainModalHandlers();
        this.setupMoveModalHandlers();
        this.setupAttackModalHandlers();
    }
    
    setupBuildModalHandlers() {
        const buildModal = document.getElementById('buildModal');
        if (!buildModal) return;
        
        // Add dynamic cost checking
        buildModal.addEventListener('show.bs.modal', () => {
            this.updateBuildOptions();
        });
        
        // Handle structure selection with visual feedback
        buildModal.querySelectorAll('.structure-option').forEach(option => {
            option.addEventListener('mouseenter', () => {
                this.showStructurePreview(option.dataset.structure);
            });
            
            option.addEventListener('mouseleave', () => {
                this.hideStructurePreview();
            });
        });
    }
    
    setupTrainModalHandlers() {
        const trainModal = document.getElementById('trainModal');
        if (!trainModal) return;
        
        trainModal.addEventListener('show.bs.modal', () => {
            this.updateTrainOptions();
            this.resetTroopQuantities();
        });
        
        // Add batch training options
        const batchButtons = this.createBatchTrainingButtons();
        trainModal.querySelector('.modal-body').appendChild(batchButtons);
    }
    
    createBatchTrainingButtons() {
        const batchContainer = document.createElement('div');
        batchContainer.className = 'batch-training mt-3';
        batchContainer.innerHTML = `
            <h6><i class="fas fa-layer-group"></i> Batch Training</h6>
            <div class="btn-group" role="group">
                <button type="button" class="btn btn-outline-warning btn-sm" data-batch="5">
                    Train 5 of Each
                </button>
                <button type="button" class="btn btn-outline-warning btn-sm" data-batch="10">
                    Train 10 of Each
                </button>
                <button type="button" class="btn btn-outline-warning btn-sm" data-batch="max">
                    Train Maximum
                </button>
            </div>
        `;
        
        // Add batch training event listeners
        batchContainer.querySelectorAll('[data-batch]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const batchSize = e.target.dataset.batch;
                this.setBatchTraining(batchSize);
            });
        });
        
        return batchContainer;
    }
    
    setupMoveModalHandlers() {
        // Create move army modal dynamically
        if (!document.getElementById('moveModal')) {
            this.createMoveModal();
        }
    }
    
    createMoveModal() {
        const modalHTML = `
            <div class="modal fade" id="moveModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="fas fa-arrows-alt"></i> Move Army</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Available Troops</h6>
                                    <div id="available-troops" class="troop-list">
                                        <!-- Dynamic content -->
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h6>Selected for Movement</h6>
                                    <div id="selected-troops" class="troop-list">
                                        <!-- Dynamic content -->
                                    </div>
                                    <div class="mt-3">
                                        <label class="form-label">Target Coordinates:</label>
                                        <div class="input-group">
                                            <input type="number" id="move-target-x" class="form-control" placeholder="X" min="0">
                                            <input type="number" id="move-target-y" class="form-control" placeholder="Y" min="0">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button class="btn btn-success" id="confirm-move-btn">
                                    <i class="fas fa-check"></i> Confirm Movement
                                </button>
                                <button class="btn btn-secondary" id="auto-target-btn">
                                    <i class="fas fa-crosshairs"></i> Click to Select Target
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        this.modals.set('moveModal', new bootstrap.Modal(document.getElementById('moveModal')));
        
        // Add event listeners
        document.getElementById('confirm-move-btn').addEventListener('click', () => {
            this.confirmMoveArmy();
        });
        
        document.getElementById('auto-target-btn').addEventListener('click', () => {
            this.enterTargetSelectionMode();
        });
    }
    
    setupAttackModalHandlers() {
        // Create attack modal dynamically
        if (!document.getElementById('attackModal')) {
            this.createAttackModal();
        }
    }
    
    createAttackModal() {
        const modalHTML = `
            <div class="modal fade" id="attackModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="fas fa-sword"></i> Attack Enemy</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Your Forces</h6>
                                    <div id="attack-troops" class="troop-list">
                                        <!-- Dynamic content -->
                                    </div>
                                    <div class="battle-prediction mt-3">
                                        <h6>Battle Prediction</h6>
                                        <div id="battle-odds" class="alert alert-info">
                                            Select troops to see battle prediction
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h6>Enemy Forces</h6>
                                    <div id="enemy-troops" class="troop-list">
                                        <!-- Dynamic content -->
                                    </div>
                                    <div class="mt-3">
                                        <label class="form-label">Target Coordinates:</label>
                                        <div class="input-group">
                                            <input type="number" id="attack-target-x" class="form-control" placeholder="X" min="0">
                                            <input type="number" id="attack-target-y" class="form-control" placeholder="Y" min="0">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button class="btn btn-danger" id="confirm-attack-btn">
                                    <i class="fas fa-sword"></i> Launch Attack
                                </button>
                                <button class="btn btn-secondary" id="auto-attack-target-btn">
                                    <i class="fas fa-crosshairs"></i> Click to Select Target
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        this.modals.set('attackModal', new bootstrap.Modal(document.getElementById('attackModal')));
        
        // Add event listeners
        document.getElementById('confirm-attack-btn').addEventListener('click', () => {
            this.confirmAttack();
        });
        
        document.getElementById('auto-attack-target-btn').addEventListener('click', () => {
            this.enterAttackTargetMode();
        });
    }
    
    setupNotificationSystem() {
        // Create notification container
        if (!document.getElementById('notification-container')) {
            const container = document.createElement('div');
            container.id = 'notification-container';
            container.className = 'notification-container';
            container.style.cssText = `
                position: fixed;
                top: 80px;
                right: 20px;
                z-index: 9999;
                max-width: 400px;
            `;
            document.body.appendChild(container);
        }
    }
    
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ignore if typing in input fields
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            
            switch (e.key.toLowerCase()) {
                case 'b':
                    e.preventDefault();
                    this.gameManager.setAction('build');
                    break;
                case 't':
                    e.preventDefault();
                    this.gameManager.setAction('train');
                    break;
                case 'm':
                    e.preventDefault();
                    this.gameManager.setAction('move');
                    break;
                case 'a':
                    e.preventDefault();
                    this.gameManager.setAction('attack');
                    break;
                case 's':
                    e.preventDefault();
                    this.gameManager.setAction('scout');
                    break;
                case 'h':
                    e.preventDefault();
                    this.gameManager.showHeroes();
                    break;
                case 'enter':
                    e.preventDefault();
                    this.gameManager.endTurn();
                    break;
                case 'r':
                    e.preventDefault();
                    this.gameManager.loadGameState();
                    break;
                case 'escape':
                    e.preventDefault();
                    this.clearSelection();
                    break;
            }
        });
    }
    
    setupTooltips() {
        // Initialize Bootstrap tooltips
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltipTriggerList.forEach(tooltipTriggerEl => {
            new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Add dynamic tooltips to map tiles
        document.addEventListener('mouseover', (e) => {
            if (e.target.classList.contains('map-tile')) {
                this.showTileTooltip(e.target, e);
            }
        });
        
        document.addEventListener('mouseout', (e) => {
            if (e.target.classList.contains('map-tile')) {
                this.hideTileTooltip();
            }
        });
    }
    
    setupContextMenus() {
        // Right-click context menu for tiles
        document.addEventListener('contextmenu', (e) => {
            if (e.target.classList.contains('map-tile')) {
                e.preventDefault();
                this.showTileContextMenu(e.target, e);
            }
        });
        
        // Close context menu on click elsewhere
        document.addEventListener('click', () => {
            this.hideContextMenu();
        });
    }
    
    setupAnimations() {
        // Add CSS for custom animations
        const style = document.createElement('style');
        style.textContent = `
            .notification-enter {
                animation: slideInRight 0.3s ease-out;
            }
            
            .notification-exit {
                animation: slideOutRight 0.3s ease-in;
            }
            
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOutRight {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            
            .tile-effect {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                font-size: 20px;
                animation: effectPulse 2s ease-out;
                pointer-events: none;
                z-index: 100;
            }
            
            @keyframes effectPulse {
                0% { transform: translate(-50%, -50%) scale(0.5); opacity: 1; }
                50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.8; }
                100% { transform: translate(-50%, -50%) scale(1.5); opacity: 0; }
            }
            
            .resource-change {
                position: absolute;
                top: -20px;
                right: 0;
                background: rgba(0, 0, 0, 0.8);
                color: white;
                padding: 2px 8px;
                border-radius: 10px;
                font-size: 12px;
                animation: resourceFloat 2s ease-out;
                pointer-events: none;
                z-index: 1000;
            }
            
            @keyframes resourceFloat {
                from { transform: translateY(0); opacity: 1; }
                to { transform: translateY(-30px); opacity: 0; }
            }
            
            .resource-gain { color: #27ae60; }
            .resource-loss { color: #e74c3c; }
        `;
        document.head.appendChild(style);
    }
    
    showNotification(message, type = 'info', duration = 5000) {
        const container = document.getElementById('notification-container');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} notification-enter`;
        notification.style.cssText = `
            margin-bottom: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            border: none;
            position: relative;
        `;
        
        const iconMap = {
            'success': 'fas fa-check-circle',
            'error': 'fas fa-exclamation-triangle',
            'warning': 'fas fa-exclamation-circle',
            'info': 'fas fa-info-circle'
        };
        
        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="${iconMap[type] || iconMap.info} me-2"></i>
                <span class="flex-grow-1">${message}</span>
                <button type="button" class="btn-close btn-close-white" onclick="this.parentElement.parentElement.remove()"></button>
            </div>
        `;
        
        container.appendChild(notification);
        
        // Auto-remove after duration
        setTimeout(() => {
            if (notification.parentNode) {
                notification.classList.add('notification-exit');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }
        }, duration);
        
        return notification;
    }
    
    showResourceChange(resourceType, amount, element) {
        if (!element) return;
        
        const change = document.createElement('div');
        change.className = `resource-change ${amount > 0 ? 'resource-gain' : 'resource-loss'}`;
        change.textContent = `${amount > 0 ? '+' : ''}${amount}`;
        
        element.style.position = 'relative';
        element.appendChild(change);
        
        setTimeout(() => {
            if (change.parentNode) {
                change.remove();
            }
        }, 2000);
    }
    
    updateBuildOptions() {
        const player = this.gameManager.gameState?.players?.[this.gameManager.playerId];
        if (!player) return;
        
        const structureCosts = {
            'farm': { gold: 50, wood: 30 },
            'barracks': { gold: 100, wood: 50, stone: 30 },
            'tower': { gold: 150, stone: 100 },
            'mine': { gold: 200, wood: 100, stone: 50 },
            'temple': { gold: 300, stone: 200 }
        };
        
        document.querySelectorAll('.structure-option').forEach(option => {
            const structureType = option.dataset.structure;
            const cost = structureCosts[structureType];
            
            if (cost) {
                const canAfford = Object.entries(cost).every(([resource, amount]) => 
                    player[resource] >= amount
                );
                
                option.classList.toggle('disabled', !canAfford);
                option.style.opacity = canAfford ? '1' : '0.5';
            }
        });
    }
    
    updateTrainOptions() {
        const player = this.gameManager.gameState?.players?.[this.gameManager.playerId];
        if (!player) return;
        
        const troopCosts = {
            'warriors': { gold: 20, food: 10 },
            'archers': { gold: 30, wood: 15 },
            'cavalry': { gold: 50, food: 20 },
            'siege': { gold: 100, wood: 50, stone: 30 }
        };
        
        document.querySelectorAll('.troop-option').forEach(option => {
            const troopType = option.dataset.troop;
            const cost = troopCosts[troopType];
            
            if (cost) {
                const maxAffordable = Math.min(
                    ...Object.entries(cost).map(([resource, amount]) => 
                        Math.floor(player[resource] / amount)
                    )
                );
                
                const quantitySpan = option.querySelector('.quantity');
                const increaseBtn = option.querySelector('[data-action="increase"]');
                
                if (quantitySpan && increaseBtn) {
                    option.dataset.maxAffordable = maxAffordable;
                    increaseBtn.disabled = maxAffordable <= 0;
                }
            }
        });
    }
    
    resetTroopQuantities() {
        document.querySelectorAll('.troop-option .quantity').forEach(span => {
            span.textContent = '1';
        });
    }
    
    setBatchTraining(batchSize) {
        document.querySelectorAll('.troop-option').forEach(option => {
            const quantitySpan = option.querySelector('.quantity');
            const maxAffordable = parseInt(option.dataset.maxAffordable || 0);
            
            if (quantitySpan) {
                let amount = 1;
                
                if (batchSize === 'max') {
                    amount = maxAffordable;
                } else {
                    amount = Math.min(parseInt(batchSize), maxAffordable);
                }
                
                quantitySpan.textContent = Math.max(1, amount);
            }
        });
    }
    
    showTileTooltip(tile, event) {
        const x = tile.dataset.x;
        const y = tile.dataset.y;
        
        // Create tooltip if it doesn't exist
        if (!this.tileTooltip) {
            this.tileTooltip = document.createElement('div');
            this.tileTooltip.className = 'tile-tooltip';
            this.tileTooltip.style.cssText = `
                position: absolute;
                background: rgba(0, 0, 0, 0.9);
                color: white;
                padding: 8px 12px;
                border-radius: 4px;
                font-size: 12px;
                z-index: 10000;
                pointer-events: none;
                max-width: 200px;
            `;
            document.body.appendChild(this.tileTooltip);
        }
        
        // Update tooltip content
        this.tileTooltip.innerHTML = `
            <strong>Tile (${x}, ${y})</strong><br>
            ${tile.classList.contains('tile-fog') ? 'Unknown terrain' : this.getTileDescription(tile)}
        `;
        
        // Position tooltip
        this.tileTooltip.style.left = event.pageX + 10 + 'px';
        this.tileTooltip.style.top = event.pageY - 10 + 'px';
        this.tileTooltip.style.display = 'block';
    }
    
    hideTileTooltip() {
        if (this.tileTooltip) {
            this.tileTooltip.style.display = 'none';
        }
    }
    
    getTileDescription(tile) {
        const terrain = Array.from(tile.classList)
            .find(cls => cls.startsWith('tile-'))
            ?.replace('tile-', '')
            ?.replace(/^(grassland|forest|mountain|water|desert)$/, match => match);
        
        return terrain ? `Terrain: ${terrain}` : 'Unknown terrain';
    }
    
    showTileContextMenu(tile, event) {
        const x = tile.dataset.x;
        const y = tile.dataset.y;
        
        // Create context menu if it doesn't exist
        if (!this.contextMenu) {
            this.contextMenu = document.createElement('div');
            this.contextMenu.className = 'context-menu';
            this.contextMenu.style.cssText = `
                position: absolute;
                background: rgba(26, 37, 47, 0.95);
                border: 1px solid #f1c40f;
                border-radius: 4px;
                z-index: 10001;
                min-width: 150px;
                backdrop-filter: blur(10px);
            `;
            document.body.appendChild(this.contextMenu);
        }
        
        // Update context menu content
        const isOwned = tile.classList.contains(`tile-owned-${this.gameManager.playerId}`);
        const hasTroops = tile.querySelector('.tile-troops');
        
        let menuItems = [
            { text: 'Select Tile', action: () => this.gameManager.mapManager.selectTile(x, y) },
            { text: 'Scout', action: () => this.gameManager.setAction('scout') }
        ];
        
        if (isOwned) {
            menuItems.push(
                { text: 'Build Structure', action: () => this.gameManager.setAction('build') },
                { text: 'Train Troops', action: () => this.gameManager.setAction('train') }
            );
            
            if (hasTroops) {
                menuItems.push(
                    { text: 'Move Army', action: () => this.gameManager.setAction('move') },
                    { text: 'Attack', action: () => this.gameManager.setAction('attack') }
                );
            }
        }
        
        this.contextMenu.innerHTML = menuItems.map(item => 
            `<div class="context-menu-item" style="padding: 8px 12px; cursor: pointer; color: white; border-bottom: 1px solid rgba(255,255,255,0.1);">
                ${item.text}
            </div>`
        ).join('');
        
        // Add event listeners
        this.contextMenu.querySelectorAll('.context-menu-item').forEach((item, index) => {
            item.addEventListener('click', () => {
                menuItems[index].action();
                this.hideContextMenu();
            });
            
            item.addEventListener('mouseenter', () => {
                item.style.background = 'rgba(241, 196, 15, 0.2)';
            });
            
            item.addEventListener('mouseleave', () => {
                item.style.background = 'transparent';
            });
        });
        
        // Position context menu
        this.contextMenu.style.left = event.pageX + 'px';
        this.contextMenu.style.top = event.pageY + 'px';
        this.contextMenu.style.display = 'block';
    }
    
    hideContextMenu() {
        if (this.contextMenu) {
            this.contextMenu.style.display = 'none';
        }
    }
    
    clearSelection() {
        this.gameManager.selectedTile = null;
        this.actionMode = null;
        document.querySelectorAll('.map-tile.selected').forEach(tile => {
            tile.classList.remove('selected');
        });
        this.hideContextMenu();
    }
    
    enterTargetSelectionMode() {
        this.actionMode = 'selecting_move_target';
        this.showNotification('Click on a tile to select movement target', 'info', 3000);
        
        // Change cursor
        document.body.style.cursor = 'crosshair';
        
        // Add temporary click handler
        const targetHandler = (e) => {
            if (e.target.classList.contains('map-tile')) {
                const x = parseInt(e.target.dataset.x);
                const y = parseInt(e.target.dataset.y);
                
                document.getElementById('move-target-x').value = x;
                document.getElementById('move-target-y').value = y;
                
                this.actionMode = null;
                document.body.style.cursor = 'default';
                document.removeEventListener('click', targetHandler);
                
                this.showNotification(`Target set to (${x}, ${y})`, 'success', 2000);
            }
        };
        
        document.addEventListener('click', targetHandler);
    }
    
    enterAttackTargetMode() {
        this.actionMode = 'selecting_attack_target';
        this.showNotification('Click on an enemy tile to attack', 'warning', 3000);
        
        document.body.style.cursor = 'crosshair';
        
        const targetHandler = (e) => {
            if (e.target.classList.contains('map-tile')) {
                const x = parseInt(e.target.dataset.x);
                const y = parseInt(e.target.dataset.y);
                
                document.getElementById('attack-target-x').value = x;
                document.getElementById('attack-target-y').value = y;
                
                this.actionMode = null;
                document.body.style.cursor = 'default';
                document.removeEventListener('click', targetHandler);
                
                this.showNotification(`Attack target set to (${x}, ${y})`, 'success', 2000);
                this.updateBattlePrediction();
            }
        };
        
        document.addEventListener('click', targetHandler);
    }
    
    confirmMoveArmy() {
        // Implementation would collect selected troops and target coordinates
        // Then call the gameManager's move army function
        this.showNotification('Move army functionality needs implementation', 'info');
    }
    
    confirmAttack() {
        // Implementation would collect selected troops and target coordinates
        // Then call the gameManager's attack function
        this.showNotification('Attack functionality needs implementation', 'info');
    }
    
    updateBattlePrediction() {
        // Calculate and display battle odds
        const battleOdds = document.getElementById('battle-odds');
        if (battleOdds) {
            battleOdds.innerHTML = 'Battle prediction calculation not implemented';
        }
    }
    
    showStructurePreview(structureType) {
        // Show preview of structure effects
        const selectedTile = this.gameManager.selectedTile;
        if (selectedTile) {
            const tile = this.gameManager.mapManager.getTileAt(selectedTile.x, selectedTile.y);
            if (tile) {
                tile.style.border = '2px dashed #f1c40f';
            }
        }
    }
    
    hideStructurePreview() {
        const selectedTile = this.gameManager.selectedTile;
        if (selectedTile) {
            const tile = this.gameManager.mapManager.getTileAt(selectedTile.x, selectedTile.y);
            if (tile) {
                tile.style.border = '';
            }
        }
    }
    
    // Helper method to get modal by ID
    getModal(modalId) {
        return this.modals.get(modalId);
    }
    
    // Helper method to show modal
    showModal(modalId) {
        const modal = this.getModal(modalId);
        if (modal) {
            modal.show();
        }
    }
    
    // Helper method to hide modal
    hideModal(modalId) {
        const modal = this.getModal(modalId);
        if (modal) {
            modal.hide();
        }
    }
}

// Initialize UI manager when game manager is ready
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (window.gameManager) {
            window.gameManager.uiManager = new UIManager(window.gameManager);
        }
    }, 150);
});
