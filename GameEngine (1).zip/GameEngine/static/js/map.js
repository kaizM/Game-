// Map rendering and interaction management
class MapManager {
    constructor(gameManager) {
        this.gameManager = gameManager;
        this.mapGrid = document.getElementById('map-grid');
        this.mapViewport = document.getElementById('map-viewport');
        this.zoomLevel = 1;
        this.tiles = new Map();
        
        this.init();
    }
    
    init() {
        if (!this.mapGrid) return;
        
        this.setupMapInteraction();
        this.generateInitialGrid();
    }
    
    setupMapInteraction() {
        // Handle tile clicks
        this.mapGrid.addEventListener('click', (event) => {
            const tile = event.target.closest('.map-tile');
            if (tile) {
                const x = parseInt(tile.dataset.x);
                const y = parseInt(tile.dataset.y);
                this.selectTile(x, y);
            }
        });
        
        // Handle tile hover
        this.mapGrid.addEventListener('mouseover', (event) => {
            const tile = event.target.closest('.map-tile');
            if (tile) {
                this.highlightTile(tile, true);
            }
        });
        
        this.mapGrid.addEventListener('mouseout', (event) => {
            const tile = event.target.closest('.map-tile');
            if (tile) {
                this.highlightTile(tile, false);
            }
        });
    }
    
    generateInitialGrid() {
        // Create a 20x20 grid by default
        this.mapGrid.innerHTML = '';
        this.tiles.clear();
        
        for (let y = 0; y < 20; y++) {
            for (let x = 0; x < 20; x++) {
                const tile = this.createTileElement(x, y);
                this.mapGrid.appendChild(tile);
                this.tiles.set(`${x},${y}`, tile);
            }
        }
    }
    
    createTileElement(x, y) {
        const tile = document.createElement('div');
        tile.className = 'map-tile tile-grassland';
        tile.dataset.x = x;
        tile.dataset.y = y;
        tile.title = `Tile (${x}, ${y})`;
        
        // Add fog of war by default
        tile.classList.add('tile-fog');
        
        return tile;
    }
    
    updateMap(gameState) {
        if (!gameState || !gameState.map) return;
        
        const mapData = gameState.map;
        const playerDiscovered = gameState.players?.[this.gameManager.playerId]?.discovered_tiles || [];
        
        // Update grid size if needed
        if (mapData.width && mapData.height) {
            this.updateGridSize(mapData.width, mapData.height);
        }
        
        // Update each tile
        Object.entries(mapData.tiles || {}).forEach(([tileKey, tileData]) => {
            const tile = this.tiles.get(tileKey);
            if (tile) {
                this.updateTileAppearance(tile, tileData, gameState);
            }
        });
    }
    
    updateGridSize(width, height) {
        const currentColumns = this.mapGrid.style.gridTemplateColumns;
        const expectedColumns = `repeat(${width}, 40px)`;
        
        if (currentColumns !== expectedColumns) {
            this.mapGrid.style.gridTemplateColumns = expectedColumns;
            this.mapGrid.style.gridTemplateRows = `repeat(${height}, 40px)`;
            
            // Regenerate grid if size changed
            this.generateGridForSize(width, height);
        }
    }
    
    generateGridForSize(width, height) {
        this.mapGrid.innerHTML = '';
        this.tiles.clear();
        
        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                const tile = this.createTileElement(x, y);
                this.mapGrid.appendChild(tile);
                this.tiles.set(`${x},${y}`, tile);
            }
        }
    }
    
    updateTileAppearance(tile, tileData, gameState) {
        const isDiscovered = tileData.discovered_by?.includes(this.gameManager.playerId);
        
        // Clear existing classes
        tile.className = 'map-tile';
        
        // Add terrain class
        if (tileData.terrain) {
            tile.classList.add(`tile-${tileData.terrain}`);
        }
        
        // Add ownership class
        if (tileData.owner) {
            tile.classList.add(`tile-owned-${tileData.owner}`);
        }
        
        // Add fog of war if not discovered
        if (!isDiscovered) {
            tile.classList.add('tile-fog');
            tile.innerHTML = '';
            return;
        }
        
        // Update tile content
        this.updateTileContent(tile, tileData);
    }
    
    updateTileContent(tile, tileData) {
        let content = '';
        
        // Add structure icons
        if (tileData.structures && tileData.structures.length > 0) {
            const structureIcons = {
                'castle': '🏰',
                'farm': '🌾',
                'barracks': '⚔️',
                'tower': '🗼',
                'mine': '⛏️',
                'temple': '⛪'
            };
            
            const primaryStructure = tileData.structures[0];
            const icon = structureIcons[primaryStructure] || '🏗️';
            content += `<div class="tile-overlay"><span class="tile-structure">${icon}</span></div>`;
        }
        
        // Add troop count
        if (tileData.troops && Object.keys(tileData.troops).length > 0) {
            const totalTroops = Object.values(tileData.troops).reduce((sum, count) => sum + count, 0);
            if (totalTroops > 0) {
                content += `<div class="tile-troops">${totalTroops}</div>`;
            }
        }
        
        tile.innerHTML = content;
    }
    
    selectTile(x, y) {
        // Remove previous selection
        document.querySelectorAll('.map-tile.selected').forEach(tile => {
            tile.classList.remove('selected');
        });
        
        // Select new tile
        const tile = this.tiles.get(`${x},${y}`);
        if (tile) {
            tile.classList.add('selected');
            this.gameManager.selectTile(x, y);
            
            // Center on selected tile
            this.centerOnTile(tile);
        }
    }
    
    highlightTile(tile, highlight) {
        if (highlight) {
            tile.style.filter = 'brightness(1.2)';
        } else {
            tile.style.filter = '';
        }
    }
    
    centerOnTile(tile) {
        if (!tile || !this.mapViewport) return;
        
        const tileRect = tile.getBoundingClientRect();
        const viewportRect = this.mapViewport.getBoundingClientRect();
        
        const scrollLeft = tile.offsetLeft - (this.mapViewport.clientWidth / 2) + (tile.offsetWidth / 2);
        const scrollTop = tile.offsetTop - (this.mapViewport.clientHeight / 2) + (tile.offsetHeight / 2);
        
        this.mapViewport.scrollTo({
            left: Math.max(0, scrollLeft),
            top: Math.max(0, scrollTop),
            behavior: 'smooth'
        });
    }
    
    zoomIn() {
        this.zoomLevel = Math.min(this.zoomLevel * 1.2, 3);
        this.applyZoom();
    }
    
    zoomOut() {
        this.zoomLevel = Math.max(this.zoomLevel / 1.2, 0.5);
        this.applyZoom();
    }
    
    applyZoom() {
        if (this.mapGrid) {
            this.mapGrid.style.transform = `scale(${this.zoomLevel})`;
            this.mapGrid.style.transformOrigin = 'top left';
        }
    }
    
    centerMap() {
        if (!this.mapViewport) return;
        
        // Find player's castle or first owned tile
        const playerTile = this.findPlayerStartingTile();
        if (playerTile) {
            this.centerOnTile(playerTile);
        } else {
            // Center on middle of map
            const middleX = Math.floor(20 / 2);
            const middleY = Math.floor(20 / 2);
            const middleTile = this.tiles.get(`${middleX},${middleY}`);
            if (middleTile) {
                this.centerOnTile(middleTile);
            }
        }
    }
    
    findPlayerStartingTile() {
        // Look for player's castle or any owned tile
        for (const [tileKey, tile] of this.tiles) {
            if (tile.classList.contains(`tile-owned-${this.gameManager.playerId}`)) {
                return tile;
            }
        }
        return null;
    }
    
    getTileAt(x, y) {
        return this.tiles.get(`${x},${y}`);
    }
    
    getAllTiles() {
        return Array.from(this.tiles.values());
    }
    
    getSelectedTile() {
        return document.querySelector('.map-tile.selected');
    }
    
    // Animation helpers
    animateTileChange(tile, animationType = 'pulse') {
        if (!tile) return;
        
        tile.classList.add(animationType);
        setTimeout(() => {
            tile.classList.remove(animationType);
        }, 1000);
    }
    
    showTileEffect(x, y, effectType = 'battle') {
        const tile = this.getTileAt(x, y);
        if (!tile) return;
        
        const effect = document.createElement('div');
        effect.className = `tile-effect tile-effect-${effectType}`;
        
        const effectIcons = {
            'battle': '⚡',
            'build': '🔨',
            'scout': '👁️',
            'move': '📦'
        };
        
        effect.innerHTML = effectIcons[effectType] || '✨';
        tile.appendChild(effect);
        
        // Remove effect after animation
        setTimeout(() => {
            if (effect.parentNode) {
                effect.parentNode.removeChild(effect);
            }
        }, 2000);
    }
}

// Initialize map manager when game manager is ready
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (window.gameManager) {
            window.gameManager.mapManager = new MapManager(window.gameManager);
        }
    }, 100);
});
