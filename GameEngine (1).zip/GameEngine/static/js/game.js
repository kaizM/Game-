// Game state management and core functionality
class GameManager {
    constructor() {
        this.playerId = document.getElementById('player-id')?.content || 'player1';
        this.selectedTile = null;
        this.gameState = null;
        this.currentAction = null;
        this.isLoading = false;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.loadGameState();
        
        // Auto-refresh every 30 seconds
        setInterval(() => {
            if (!this.isLoading) {
                this.loadGameState();
            }
        }, 30000);
    }
    
    setupEventListeners() {
        // Refresh button
        document.getElementById('refresh-btn')?.addEventListener('click', () => {
            this.loadGameState();
        });
        
        // End turn button
        document.getElementById('end-turn-btn')?.addEventListener('click', () => {
            this.endTurn();
        });
        
        // Action buttons
        document.getElementById('build-btn')?.addEventListener('click', () => {
            this.setAction('build');
        });
        
        document.getElementById('train-btn')?.addEventListener('click', () => {
            this.setAction('train');
        });
        
        document.getElementById('move-btn')?.addEventListener('click', () => {
            this.setAction('move');
        });
        
        document.getElementById('attack-btn')?.addEventListener('click', () => {
            this.setAction('attack');
        });
        
        document.getElementById('scout-btn')?.addEventListener('click', () => {
            this.setAction('scout');
        });
        
        document.getElementById('heroes-btn')?.addEventListener('click', () => {
            this.showHeroes();
        });
        
        // Map controls
        document.getElementById('zoom-in')?.addEventListener('click', () => {
            this.mapManager.zoomIn();
        });
        
        document.getElementById('zoom-out')?.addEventListener('click', () => {
            this.mapManager.zoomOut();
        });
        
        document.getElementById('center-map')?.addEventListener('click', () => {
            this.mapManager.centerMap();
        });
        
        // Modal event listeners
        this.setupModalListeners();
    }
    
    setupModalListeners() {
        // Build structure modal
        document.querySelectorAll('.structure-option').forEach(option => {
            option.addEventListener('click', () => {
                document.querySelectorAll('.structure-option').forEach(o => o.classList.remove('selected'));
                option.classList.add('selected');
                
                const structureType = option.dataset.structure;
                this.buildStructure(structureType);
            });
        });
        
        // Train troops modal
        document.querySelectorAll('.troop-option').forEach(option => {
            const decreaseBtn = option.querySelector('[data-action="decrease"]');
            const increaseBtn = option.querySelector('[data-action="increase"]');
            const quantitySpan = option.querySelector('.quantity');
            
            decreaseBtn?.addEventListener('click', () => {
                let quantity = parseInt(quantitySpan.textContent);
                if (quantity > 1) {
                    quantitySpan.textContent = quantity - 1;
                }
            });
            
            increaseBtn?.addEventListener('click', () => {
                let quantity = parseInt(quantitySpan.textContent);
                if (quantity < 10) {
                    quantitySpan.textContent = quantity + 1;
                }
            });
        });
        
        document.getElementById('confirm-train-btn')?.addEventListener('click', () => {
            this.confirmTrainTroops();
        });
    }
    
    async loadGameState() {
        try {
            this.showLoading(true);
            const response = await fetch('/api/game-state');
            
            if (!response.ok) {
                throw new Error('Failed to load game state');
            }
            
            this.gameState = await response.json();
            this.updateUI();
            this.mapManager?.updateMap(this.gameState);
            
            this.log('Game state updated', 'info');
        } catch (error) {
            this.log(`Error loading game state: ${error.message}`, 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    async loadPlayerStats() {
        try {
            const response = await fetch(`/api/player/${this.playerId}/stats`);
            
            if (!response.ok) {
                throw new Error('Failed to load player stats');
            }
            
            const stats = await response.json();
            this.updateResourceDisplay(stats);
        } catch (error) {
            this.log(`Error loading player stats: ${error.message}`, 'error');
        }
    }
    
    updateUI() {
        if (!this.gameState) return;
        
        // Update game info
        document.getElementById('game-day').textContent = this.gameState.day || 1;
        document.getElementById('game-tick').textContent = this.gameState.tick || 0;
        document.getElementById('current-player').textContent = this.gameState.current_player || this.playerId;
        
        // Update player resources
        const player = this.gameState.players?.[this.playerId];
        if (player) {
            this.updateResourceDisplay(player);
        }
        
        // Update current player indicator
        const isMyTurn = this.gameState.current_player === this.playerId;
        document.getElementById('end-turn-btn').disabled = !isMyTurn;
        
        if (isMyTurn) {
            document.getElementById('current-player').classList.add('text-success');
        } else {
            document.getElementById('current-player').classList.remove('text-success');
        }
    }
    
    updateResourceDisplay(player) {
        document.getElementById('gold').textContent = player.gold || 0;
        document.getElementById('food').textContent = player.food || 0;
        document.getElementById('wood').textContent = player.wood || 0;
        document.getElementById('stone').textContent = player.stone || 0;
        document.getElementById('population').textContent = player.population || 0;
        document.getElementById('max-population').textContent = player.max_population || 100;
    }
    
    selectTile(x, y) {
        this.selectedTile = { x, y };
        this.updateTileInfo(x, y);
        this.updateActionButtons();
    }
    
    async updateTileInfo(x, y) {
        try {
            const response = await fetch(`/api/tile/${x}/${y}`);
            
            if (!response.ok) {
                throw new Error('Failed to load tile info');
            }
            
            const tileInfo = await response.json();
            this.displayTileInfo(tileInfo);
        } catch (error) {
            this.log(`Error loading tile info: ${error.message}`, 'error');
        }
    }
    
    displayTileInfo(tile) {
        const tileDetails = document.getElementById('tile-details');
        if (!tileDetails || !tile) return;
        
        const isOwned = tile.owner === this.playerId;
        const ownerText = tile.owner ? tile.owner : 'Unowned';
        const terrainText = tile.terrain || 'Unknown';
        
        let html = `
            <div class="tile-detail-item">
                <span class="tile-detail-label">Position:</span>
                <span>(${tile.x}, ${tile.y})</span>
            </div>
            <div class="tile-detail-item">
                <span class="tile-detail-label">Terrain:</span>
                <span>${terrainText}</span>
            </div>
            <div class="tile-detail-item">
                <span class="tile-detail-label">Owner:</span>
                <span class="${isOwned ? 'text-success' : 'text-warning'}">${ownerText}</span>
            </div>
        `;
        
        // Show structures
        if (tile.structures && tile.structures.length > 0) {
            html += `
                <div class="tile-detail-item">
                    <span class="tile-detail-label">Structures:</span>
                    <span>${tile.structures.join(', ')}</span>
                </div>
            `;
        }
        
        // Show troops
        if (tile.troops && Object.keys(tile.troops).length > 0) {
            const troopsList = Object.entries(tile.troops)
                .map(([type, count]) => `${count} ${type}`)
                .join(', ');
            html += `
                <div class="tile-detail-item">
                    <span class="tile-detail-label">Troops:</span>
                    <span>${troopsList}</span>
                </div>
            `;
        }
        
        // Show resources
        if (tile.resources && Object.keys(tile.resources).length > 0) {
            const resourcesList = Object.entries(tile.resources)
                .map(([type, amount]) => `${amount} ${type}`)
                .join(', ');
            html += `
                <div class="tile-detail-item">
                    <span class="tile-detail-label">Resources:</span>
                    <span>${resourcesList}</span>
                </div>
            `;
        }
        
        tileDetails.innerHTML = html;
    }
    
    updateActionButtons() {
        const hasSelectedTile = this.selectedTile !== null;
        const isMyTurn = this.gameState?.current_player === this.playerId;
        
        document.getElementById('build-btn').disabled = !hasSelectedTile || !isMyTurn;
        document.getElementById('train-btn').disabled = !hasSelectedTile || !isMyTurn;
        document.getElementById('move-btn').disabled = !hasSelectedTile || !isMyTurn;
        document.getElementById('attack-btn').disabled = !hasSelectedTile || !isMyTurn;
        document.getElementById('scout-btn').disabled = !hasSelectedTile || !isMyTurn;
    }
    
    setAction(action) {
        if (!this.selectedTile) {
            this.log('Please select a tile first', 'warning');
            return;
        }
        
        this.currentAction = action;
        
        switch (action) {
            case 'build':
                this.showBuildModal();
                break;
            case 'train':
                this.showTrainModal();
                break;
            case 'scout':
                this.scoutTile();
                break;
            default:
                this.log(`Action ${action} not implemented yet`, 'info');
        }
    }
    
    showBuildModal() {
        const modal = new bootstrap.Modal(document.getElementById('buildModal'));
        modal.show();
    }
    
    showTrainModal() {
        const modal = new bootstrap.Modal(document.getElementById('trainModal'));
        modal.show();
    }
    
    async buildStructure(structureType) {
        if (!this.selectedTile) return;
        
        try {
            this.showLoading(true);
            
            const response = await fetch('/api/build', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    x: this.selectedTile.x,
                    y: this.selectedTile.y,
                    structure_type: structureType,
                    player_id: this.playerId
                }),
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.log(`${structureType} built successfully!`, 'success');
                this.loadGameState();
                bootstrap.Modal.getInstance(document.getElementById('buildModal'))?.hide();
            } else {
                this.log(`Failed to build ${structureType}: ${result.message}`, 'error');
            }
        } catch (error) {
            this.log(`Error building structure: ${error.message}`, 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    async confirmTrainTroops() {
        if (!this.selectedTile) return;
        
        const selectedTroops = [];
        document.querySelectorAll('.troop-option').forEach(option => {
            const quantity = parseInt(option.querySelector('.quantity').textContent);
            if (quantity > 0) {
                selectedTroops.push({
                    type: option.dataset.troop,
                    quantity: quantity
                });
            }
        });
        
        if (selectedTroops.length === 0) {
            this.log('Please select troops to train', 'warning');
            return;
        }
        
        try {
            this.showLoading(true);
            
            for (const troop of selectedTroops) {
                const response = await fetch('/api/train-troops', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        x: this.selectedTile.x,
                        y: this.selectedTile.y,
                        troop_type: troop.type,
                        quantity: troop.quantity,
                        player_id: this.playerId
                    }),
                });
                
                const result = await response.json();
                
                if (result.success) {
                    this.log(`Trained ${troop.quantity} ${troop.type}!`, 'success');
                } else {
                    this.log(`Failed to train ${troop.type}: ${result.message}`, 'error');
                }
            }
            
            this.loadGameState();
            bootstrap.Modal.getInstance(document.getElementById('trainModal'))?.hide();
            
            // Reset quantities
            document.querySelectorAll('.troop-option .quantity').forEach(span => {
                span.textContent = '1';
            });
            
        } catch (error) {
            this.log(`Error training troops: ${error.message}`, 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    async scoutTile() {
        if (!this.selectedTile) return;
        
        try {
            this.showLoading(true);
            
            const response = await fetch('/api/scout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    x: this.selectedTile.x,
                    y: this.selectedTile.y,
                    player_id: this.playerId
                }),
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.log('Tile scouted successfully!', 'success');
                this.loadGameState();
                this.updateTileInfo(this.selectedTile.x, this.selectedTile.y);
            } else {
                this.log(`Failed to scout tile: ${result.message}`, 'error');
            }
        } catch (error) {
            this.log(`Error scouting tile: ${error.message}`, 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    async endTurn() {
        try {
            this.showLoading(true);
            
            const response = await fetch('/api/end-turn', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.log(`Turn ended. Next player: ${result.next_player}`, 'info');
                this.loadGameState();
            } else {
                this.log(`Failed to end turn: ${result.message}`, 'error');
            }
        } catch (error) {
            this.log(`Error ending turn: ${error.message}`, 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    showHeroes() {
        this.log('Heroes feature coming soon!', 'info');
    }
    
    showLoading(show) {
        this.isLoading = show;
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.classList.toggle('show', show);
        }
    }
    
    log(message, type = 'info') {
        const gameLog = document.getElementById('game-log');
        if (!gameLog) return;
        
        const logEntry = document.createElement('p');
        logEntry.className = `log-${type} fade-in`;
        logEntry.innerHTML = `<small>${new Date().toLocaleTimeString()}</small> ${message}`;
        
        gameLog.appendChild(logEntry);
        gameLog.scrollTop = gameLog.scrollHeight;
        
        // Remove old log entries (keep only last 50)
        while (gameLog.children.length > 50) {
            gameLog.removeChild(gameLog.firstChild);
        }
    }
}

// Initialize game manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.gameManager = new GameManager();
});
