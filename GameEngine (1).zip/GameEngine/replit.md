# Overview

This is a turn-based strategy game built with Flask and JavaScript, featuring kingdom management, AI opponents, and tactical combat. Players build structures, train troops, manage resources, and engage in strategic battles on a grid-based map. The game includes multiple AI personalities, hero recruitment, and a real-time web interface with particle effects and interactive map controls.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Web Framework**: Flask-based server-side rendering with Jinja2 templates
- **Client Interface**: HTML5/CSS3/JavaScript with Bootstrap 5 for responsive UI
- **Map System**: Canvas-based grid rendering with interactive tile selection and hover effects
- **Real-time Updates**: Polling-based state synchronization every 30 seconds
- **Visual Effects**: Custom particle system with canvas overlay for battle animations
- **UI Components**: Modal-based action dialogs, notification system, and context menus

## Backend Architecture
- **Game Engine**: Object-oriented Python architecture with centralized GameEngine class
- **State Management**: File-based persistence using JSON serialization
- **AI System**: Pluggable AI personalities (aggressive, defensive, economic, balanced) with decision trees
- **Turn Processing**: Sequential turn-based mechanics with action validation
- **Hero System**: RPG-style character management with stats, abilities, and recruitment

## Data Storage Solutions
- **Primary Storage**: JSON file-based game state persistence (`game_state.json`)
- **Session Management**: Flask session handling for player identification
- **Game State Structure**: Hierarchical data model with players, map tiles, resources, and turn tracking
- **No Database**: Currently uses file system for simplicity, easily upgradeable to database

## Authentication and Authorization
- **Session-based**: Flask session management for player identification
- **Simple Player ID**: Basic player tracking without complex authentication
- **Action Validation**: Server-side validation of player actions and resource requirements

# External Dependencies

## Python Libraries
- **Flask**: Web framework for routing and templating
- **Werkzeug**: WSGI utilities and proxy handling for deployment
- **Standard Library**: JSON, logging, random, datetime, typing for core functionality

## Frontend Libraries
- **Bootstrap 5**: CSS framework for responsive design and UI components
- **Font Awesome 6**: Icon library for game interface elements
- **Vanilla JavaScript**: No framework dependencies, pure DOM manipulation

## Development Tools
- **Python Logging**: Built-in debugging and error tracking
- **Flask Debug Mode**: Development server with auto-reload
- **Static Asset Serving**: Flask static file handling for CSS/JS/images

## Potential Future Integrations
- **Database**: Ready for PostgreSQL or SQLite integration to replace JSON storage
- **WebSocket**: Prepared for real-time multiplayer with socket connections
- **Authentication**: Extensible for OAuth or user registration systems
- **CDN**: Static assets can be moved to external CDN for production scaling