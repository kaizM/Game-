import json
import os
import logging
import random
from datetime import datetime
from typing import Dict, List, Any, Optional

class GameEngine:
    def __init__(self):
        self.game_state_file = 'game_state.json'
        self.load_game_state()
    
    def load_game_state(self):
        """Load game state from JSON file"""
        if os.path.exists(self.game_state_file):
            try:
                with open(self.game_state_file, 'r') as f:
                    self.game_state = json.load(f)
            except Exception as e:
                logging.error(f"Error loading game state: {e}")
                self.initialize_new_game()
        else:
            self.initialize_new_game()
    
    def save_game_state(self):
        """Save game state to JSON file"""
        try:
            with open(self.game_state_file, 'w') as f:
                json.dump(self.game_state, f, indent=2)
        except Exception as e:
            logging.error(f"Error saving game state: {e}")
    
    def initialize_new_game(self):
        """Initialize a new game with default state"""
        self.game_state = {
            'day': 1,
            'tick': 0,
            'current_player': 'player1',
            'players': {
                'player1': {
                    'name': 'Player 1',
                    'gold': 1000,
                    'food': 500,
                    'wood': 300,
                    'stone': 200,
                    'population': 50,
                    'max_population': 100,
                    'castle_level': 1,
                    'technologies': [],
                    'heroes': []
                },
                'ai_player1': {
                    'name': 'AI Player 1',
                    'gold': 1000,
                    'food': 500,
                    'wood': 300,
                    'stone': 200,
                    'population': 50,
                    'max_population': 100,
                    'castle_level': 1,
                    'technologies': [],
                    'heroes': []
                }
            },
            'map': self.generate_map(20, 20),
            'turn_order': ['player1', 'ai_player1'],
            'turn_actions': {},
            'events': [],
            'last_update': datetime.now().isoformat()
        }
        self.save_game_state()
    
    def generate_map(self, width: int, height: int) -> Dict:
        """Generate a random map with various terrain types"""
        map_data = {
            'width': width,
            'height': height,
            'tiles': {}
        }
        
        terrain_types = ['grassland', 'forest', 'mountain', 'water', 'desert']
        
        for x in range(width):
            for y in range(height):
                tile_key = f"{x},{y}"
                
                # Generate terrain based on position
                if x == 0 and y == 0:
                    # Player 1 starting position
                    terrain = 'grassland'
                    owner = 'player1'
                    structures = ['castle']
                    troops = {'warriors': 10, 'archers': 5}
                elif x == width-1 and y == height-1:
                    # AI starting position
                    terrain = 'grassland'
                    owner = 'ai_player1'
                    structures = ['castle']
                    troops = {'warriors': 10, 'archers': 5}
                else:
                    terrain = random.choice(terrain_types)
                    owner = None
                    structures = []
                    troops = {}
                
                map_data['tiles'][tile_key] = {
                    'x': x,
                    'y': y,
                    'terrain': terrain,
                    'owner': owner,
                    'structures': structures,
                    'troops': troops,
                    'resources': self.generate_tile_resources(terrain),
                    'discovered_by': [owner] if owner else [],
                    'fog_of_war': True
                }
        
        return map_data
    
    def generate_tile_resources(self, terrain: str) -> Dict:
        """Generate resources based on terrain type"""
        base_resources = {
            'grassland': {'food': random.randint(10, 30)},
            'forest': {'wood': random.randint(20, 40), 'food': random.randint(5, 15)},
            'mountain': {'stone': random.randint(30, 50), 'gold': random.randint(10, 25)},
            'water': {'food': random.randint(15, 35)},
            'desert': {'gold': random.randint(5, 20)}
        }
        return base_resources.get(terrain, {})
    
    def get_game_state(self) -> Dict:
        """Get the current game state"""
        return self.game_state
    
    def get_player_stats(self, player_id: str) -> Dict:
        """Get specific player statistics"""
        if player_id in self.game_state['players']:
            return self.game_state['players'][player_id]
        return {'error': 'Player not found'}
    
    def get_tile_info(self, x: int, y: int) -> Dict:
        """Get information about a specific tile"""
        tile_key = f"{x},{y}"
        if tile_key in self.game_state['map']['tiles']:
            return self.game_state['map']['tiles'][tile_key]
        return {'error': 'Tile not found'}
    
    def build_structure(self, player_id: str, x: int, y: int, structure_type: str) -> Dict:
        """Build a structure on a tile"""
        tile_key = f"{x},{y}"
        
        if tile_key not in self.game_state['map']['tiles']:
            return {'success': False, 'message': 'Invalid tile coordinates'}
        
        tile = self.game_state['map']['tiles'][tile_key]
        
        if tile['owner'] != player_id:
            return {'success': False, 'message': 'You do not own this tile'}
        
        # Check if structure can be built
        structure_costs = {
            'farm': {'gold': 50, 'wood': 30},
            'barracks': {'gold': 100, 'wood': 50, 'stone': 30},
            'tower': {'gold': 150, 'stone': 100},
            'mine': {'gold': 200, 'wood': 100, 'stone': 50},
            'temple': {'gold': 300, 'stone': 200}
        }
        
        if structure_type not in structure_costs:
            return {'success': False, 'message': 'Invalid structure type'}
        
        player = self.game_state['players'][player_id]
        cost = structure_costs[structure_type]
        
        # Check if player has enough resources
        for resource, amount in cost.items():
            if player.get(resource, 0) < amount:
                return {'success': False, 'message': f'Not enough {resource}'}
        
        # Deduct resources and build structure
        for resource, amount in cost.items():
            player[resource] -= amount
        
        tile['structures'].append(structure_type)
        self.save_game_state()
        
        return {'success': True, 'message': f'{structure_type} built successfully'}
    
    def train_troops(self, player_id: str, x: int, y: int, troop_type: str, quantity: int) -> Dict:
        """Train troops at a structure"""
        tile_key = f"{x},{y}"
        
        if tile_key not in self.game_state['map']['tiles']:
            return {'success': False, 'message': 'Invalid tile coordinates'}
        
        tile = self.game_state['map']['tiles'][tile_key]
        
        if tile['owner'] != player_id:
            return {'success': False, 'message': 'You do not own this tile'}
        
        if 'barracks' not in tile['structures'] and 'castle' not in tile['structures']:
            return {'success': False, 'message': 'No training facility available'}
        
        # Troop costs
        troop_costs = {
            'warriors': {'gold': 20, 'food': 10},
            'archers': {'gold': 30, 'wood': 15},
            'cavalry': {'gold': 50, 'food': 20},
            'siege': {'gold': 100, 'wood': 50, 'stone': 30}
        }
        
        if troop_type not in troop_costs:
            return {'success': False, 'message': 'Invalid troop type'}
        
        player = self.game_state['players'][player_id]
        cost_per_unit = troop_costs[troop_type]
        total_cost = {resource: amount * quantity for resource, amount in cost_per_unit.items()}
        
        # Check if player has enough resources
        for resource, amount in total_cost.items():
            if player.get(resource, 0) < amount:
                return {'success': False, 'message': f'Not enough {resource}'}
        
        # Check population limit
        current_pop = player.get('population', 0)
        max_pop = player.get('max_population', 100)
        if current_pop + quantity > max_pop:
            return {'success': False, 'message': 'Population limit exceeded'}
        
        # Deduct resources and train troops
        for resource, amount in total_cost.items():
            player[resource] -= amount
        
        player['population'] += quantity
        
        if troop_type not in tile['troops']:
            tile['troops'][troop_type] = 0
        tile['troops'][troop_type] += quantity
        
        self.save_game_state()
        
        return {'success': True, 'message': f'{quantity} {troop_type} trained successfully'}
    
    def move_army(self, player_id: str, from_x: int, from_y: int, to_x: int, to_y: int, troops: Dict) -> Dict:
        """Move army from one tile to another"""
        from_key = f"{from_x},{from_y}"
        to_key = f"{to_x},{to_y}"
        
        if from_key not in self.game_state['map']['tiles'] or to_key not in self.game_state['map']['tiles']:
            return {'success': False, 'message': 'Invalid tile coordinates'}
        
        from_tile = self.game_state['map']['tiles'][from_key]
        to_tile = self.game_state['map']['tiles'][to_key]
        
        if from_tile['owner'] != player_id:
            return {'success': False, 'message': 'You do not own the source tile'}
        
        # Check if troops are available
        for troop_type, quantity in troops.items():
            if from_tile['troops'].get(troop_type, 0) < quantity:
                return {'success': False, 'message': f'Not enough {troop_type} available'}
        
        # Calculate movement distance (simple Manhattan distance)
        distance = abs(to_x - from_x) + abs(to_y - from_y)
        if distance > 3:  # Maximum movement range
            return {'success': False, 'message': 'Target too far for movement'}
        
        # Move troops
        for troop_type, quantity in troops.items():
            from_tile['troops'][troop_type] -= quantity
            if from_tile['troops'][troop_type] <= 0:
                del from_tile['troops'][troop_type]
            
            if troop_type not in to_tile['troops']:
                to_tile['troops'][troop_type] = 0
            to_tile['troops'][troop_type] += quantity
        
        # If moving to unowned tile, claim it
        if not to_tile['owner']:
            to_tile['owner'] = player_id
        
        # Reveal fog of war
        if player_id not in to_tile['discovered_by']:
            to_tile['discovered_by'].append(player_id)
        
        self.save_game_state()
        
        return {'success': True, 'message': 'Army moved successfully'}
    
    def scout_tile(self, player_id: str, x: int, y: int) -> Dict:
        """Scout a tile to reveal information"""
        tile_key = f"{x},{y}"
        
        if tile_key not in self.game_state['map']['tiles']:
            return {'success': False, 'message': 'Invalid tile coordinates'}
        
        tile = self.game_state['map']['tiles'][tile_key]
        
        # Add player to discovered_by list
        if player_id not in tile['discovered_by']:
            tile['discovered_by'].append(player_id)
        
        self.save_game_state()
        
        return {
            'success': True,
            'message': 'Tile scouted successfully',
            'tile_info': tile
        }
    
    def attack_tile(self, player_id: str, from_x: int, from_y: int, to_x: int, to_y: int, troops: Dict) -> Dict:
        """Attack a tile"""
        from_key = f"{from_x},{from_y}"
        to_key = f"{to_x},{to_y}"
        
        if from_key not in self.game_state['map']['tiles'] or to_key not in self.game_state['map']['tiles']:
            return {'success': False, 'message': 'Invalid tile coordinates'}
        
        from_tile = self.game_state['map']['tiles'][from_key]
        to_tile = self.game_state['map']['tiles'][to_key]
        
        if from_tile['owner'] != player_id:
            return {'success': False, 'message': 'You do not own the source tile'}
        
        if not to_tile['owner'] or to_tile['owner'] == player_id:
            return {'success': False, 'message': 'Cannot attack unowned or own tile'}
        
        # Calculate attack distance
        distance = abs(to_x - from_x) + abs(to_y - from_y)
        if distance > 2:  # Maximum attack range
            return {'success': False, 'message': 'Target too far for attack'}
        
        # Check if attacking troops are available
        for troop_type, quantity in troops.items():
            if from_tile['troops'].get(troop_type, 0) < quantity:
                return {'success': False, 'message': f'Not enough {troop_type} available'}
        
        # Calculate battle outcome
        attack_power = sum(self.get_troop_power(troop_type) * quantity for troop_type, quantity in troops.items())
        defense_power = sum(self.get_troop_power(troop_type) * quantity for troop_type, quantity in to_tile['troops'].items())
        
        # Add defensive bonus for structures
        if 'tower' in to_tile['structures']:
            defense_power *= 1.5
        if 'castle' in to_tile['structures']:
            defense_power *= 2.0
        
        # Battle resolution
        if attack_power > defense_power:
            # Attacker wins
            casualty_rate = 0.3
            for troop_type, quantity in troops.items():
                casualties = int(quantity * casualty_rate)
                from_tile['troops'][troop_type] -= casualties
                if from_tile['troops'][troop_type] <= 0:
                    del from_tile['troops'][troop_type]
            
            # Clear defending troops
            to_tile['troops'] = {}
            
            # Transfer ownership
            old_owner = to_tile['owner']
            to_tile['owner'] = player_id
            
            # Move surviving attacking troops
            for troop_type, quantity in troops.items():
                survivors = from_tile['troops'].get(troop_type, 0)
                if survivors > 0:
                    from_tile['troops'][troop_type] -= survivors
                    if from_tile['troops'][troop_type] <= 0:
                        del from_tile['troops'][troop_type]
                    
                    if troop_type not in to_tile['troops']:
                        to_tile['troops'][troop_type] = 0
                    to_tile['troops'][troop_type] += survivors
            
            self.save_game_state()
            return {'success': True, 'message': f'Victory! Captured tile from {old_owner}'}
        else:
            # Defender wins
            casualty_rate = 0.8
            for troop_type, quantity in troops.items():
                casualties = int(quantity * casualty_rate)
                from_tile['troops'][troop_type] -= casualties
                if from_tile['troops'][troop_type] <= 0:
                    del from_tile['troops'][troop_type]
            
            self.save_game_state()
            return {'success': False, 'message': 'Attack failed! Heavy casualties sustained'}
    
    def get_troop_power(self, troop_type: str) -> int:
        """Get the combat power of a troop type"""
        power_values = {
            'warriors': 10,
            'archers': 8,
            'cavalry': 15,
            'siege': 20
        }
        return power_values.get(troop_type, 5)
    
    def end_turn(self, player_id: str) -> Dict:
        """End current player's turn"""
        if self.game_state['current_player'] != player_id:
            return {'success': False, 'message': 'Not your turn'}
        
        # Process end-of-turn effects
        self.process_resource_generation(player_id)
        
        # Advance to next player
        current_index = self.game_state['turn_order'].index(player_id)
        next_index = (current_index + 1) % len(self.game_state['turn_order'])
        self.game_state['current_player'] = self.game_state['turn_order'][next_index]
        
        # If back to first player, advance day
        if next_index == 0:
            self.game_state['day'] += 1
        
        self.game_state['tick'] += 1
        self.game_state['last_update'] = datetime.now().isoformat()
        
        self.save_game_state()
        
        return {'success': True, 'message': 'Turn ended successfully', 'next_player': self.game_state['current_player']}
    
    def process_resource_generation(self, player_id: str):
        """Process resource generation for a player"""
        player = self.game_state['players'][player_id]
        
        # Generate resources from owned tiles
        for tile_key, tile in self.game_state['map']['tiles'].items():
            if tile['owner'] == player_id:
                # Base resource generation from terrain
                for resource, amount in tile['resources'].items():
                    if resource in player:
                        player[resource] += amount // 10  # Reduced rate for balance
                
                # Structure bonuses
                for structure in tile['structures']:
                    if structure == 'farm':
                        player['food'] += 20
                    elif structure == 'mine':
                        player['gold'] += 15
                        player['stone'] += 10
