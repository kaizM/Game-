import random
import logging
from typing import Dict, List, Any

class AIPlayer:
    def __init__(self):
        self.personality = 'balanced'  # aggressive, defensive, economic, balanced
        
    def make_turn(self, game_engine, ai_player_id: str) -> List[Dict]:
        """Make AI turn decisions"""
        actions = []
        game_state = game_engine.get_game_state()
        ai_player = game_state['players'][ai_player_id]
        
        # Get AI owned tiles
        ai_tiles = []
        for tile_key, tile in game_state['map']['tiles'].items():
            if tile['owner'] == ai_player_id:
                ai_tiles.append((tile_key, tile))
        
        if not ai_tiles:
            return actions
        
        # Decision making based on personality and game state
        actions.extend(self.decide_buildings(game_engine, ai_player_id, ai_tiles, ai_player))
        actions.extend(self.decide_troop_training(game_engine, ai_player_id, ai_tiles, ai_player))
        actions.extend(self.decide_expansion(game_engine, ai_player_id, ai_tiles, game_state))
        actions.extend(self.decide_attacks(game_engine, ai_player_id, ai_tiles, game_state))
        
        return actions
    
    def decide_buildings(self, game_engine, ai_player_id: str, ai_tiles: List, ai_player: Dict) -> List[Dict]:
        """Decide what buildings to construct"""
        actions = []
        
        for tile_key, tile in ai_tiles:
            x, y = map(int, tile_key.split(','))
            
            # Build farms if food is low
            if ai_player['food'] < 200 and 'farm' not in tile['structures']:
                if ai_player['gold'] >= 50 and ai_player['wood'] >= 30:
                    result = game_engine.build_structure(ai_player_id, x, y, 'farm')
                    if result['success']:
                        actions.append({'action': 'build', 'structure': 'farm', 'x': x, 'y': y})
            
            # Build barracks for military
            if len([s for s in tile['structures'] if s in ['barracks', 'castle']]) == 0:
                if ai_player['gold'] >= 100 and ai_player['wood'] >= 50 and ai_player['stone'] >= 30:
                    result = game_engine.build_structure(ai_player_id, x, y, 'barracks')
                    if result['success']:
                        actions.append({'action': 'build', 'structure': 'barracks', 'x': x, 'y': y})
            
            # Build towers for defense
            if 'tower' not in tile['structures'] and random.random() < 0.3:
                if ai_player['gold'] >= 150 and ai_player['stone'] >= 100:
                    result = game_engine.build_structure(ai_player_id, x, y, 'tower')
                    if result['success']:
                        actions.append({'action': 'build', 'structure': 'tower', 'x': x, 'y': y})
        
        return actions
    
    def decide_troop_training(self, game_engine, ai_player_id: str, ai_tiles: List, ai_player: Dict) -> List[Dict]:
        """Decide what troops to train"""
        actions = []
        
        for tile_key, tile in ai_tiles:
            if 'barracks' in tile['structures'] or 'castle' in tile['structures']:
                x, y = map(int, tile_key.split(','))
                
                # Train warriors if we have resources
                if ai_player['gold'] >= 40 and ai_player['food'] >= 20:
                    quantity = min(2, ai_player['gold'] // 20)
                    result = game_engine.train_troops(ai_player_id, x, y, 'warriors', quantity)
                    if result['success']:
                        actions.append({'action': 'train', 'troop': 'warriors', 'quantity': quantity, 'x': x, 'y': y})
                
                # Train archers occasionally
                if ai_player['gold'] >= 60 and ai_player['wood'] >= 30 and random.random() < 0.4:
                    quantity = min(2, ai_player['gold'] // 30)
                    result = game_engine.train_troops(ai_player_id, x, y, 'archers', quantity)
                    if result['success']:
                        actions.append({'action': 'train', 'troop': 'archers', 'quantity': quantity, 'x': x, 'y': y})
        
        return actions
    
    def decide_expansion(self, game_engine, ai_player_id: str, ai_tiles: List, game_state: Dict) -> List[Dict]:
        """Decide on expansion moves"""
        actions = []
        
        for tile_key, tile in ai_tiles:
            if not tile['troops']:
                continue
                
            x, y = map(int, tile_key.split(','))
            
            # Look for adjacent unowned tiles
            adjacent_coords = [
                (x-1, y), (x+1, y), (x, y-1), (x, y+1)
            ]
            
            for adj_x, adj_y in adjacent_coords:
                adj_key = f"{adj_x},{adj_y}"
                if adj_key in game_state['map']['tiles']:
                    adj_tile = game_state['map']['tiles'][adj_key]
                    
                    # Move to unowned tiles
                    if not adj_tile['owner']:
                        # Send some troops to claim the tile
                        troops_to_send = {}
                        for troop_type, quantity in tile['troops'].items():
                            if quantity > 2:  # Keep some troops for defense
                                troops_to_send[troop_type] = min(2, quantity - 1)
                        
                        if troops_to_send:
                            result = game_engine.move_army(ai_player_id, x, y, adj_x, adj_y, troops_to_send)
                            if result['success']:
                                actions.append({'action': 'move', 'from': (x, y), 'to': (adj_x, adj_y), 'troops': troops_to_send})
                                break  # Only one expansion per tile per turn
        
        return actions
    
    def decide_attacks(self, game_engine, ai_player_id: str, ai_tiles: List, game_state: Dict) -> List[Dict]:
        """Decide on attack actions"""
        actions = []
        
        if self.personality == 'defensive':
            return actions  # Defensive AI doesn't attack
        
        for tile_key, tile in ai_tiles:
            if not tile['troops']:
                continue
                
            x, y = map(int, tile_key.split(','))
            total_troops = sum(tile['troops'].values())
            
            if total_troops < 5:  # Need minimum troops to attack
                continue
            
            # Look for adjacent enemy tiles
            adjacent_coords = [
                (x-1, y), (x+1, y), (x, y-1), (x, y+1)
            ]
            
            for adj_x, adj_y in adjacent_coords:
                adj_key = f"{adj_x},{adj_y}"
                if adj_key in game_state['map']['tiles']:
                    adj_tile = game_state['map']['tiles'][adj_key]
                    
                    # Attack enemy tiles
                    if adj_tile['owner'] and adj_tile['owner'] != ai_player_id:
                        enemy_troops = sum(adj_tile['troops'].values())
                        
                        # Only attack if we have advantage
                        if total_troops > enemy_troops * 1.5:
                            # Send majority of troops to attack
                            troops_to_attack = {}
                            for troop_type, quantity in tile['troops'].items():
                                troops_to_attack[troop_type] = max(1, quantity - 1)  # Keep 1 for defense
                            
                            if troops_to_attack:
                                result = game_engine.attack_tile(ai_player_id, x, y, adj_x, adj_y, troops_to_attack)
                                actions.append({'action': 'attack', 'from': (x, y), 'to': (adj_x, adj_y), 'troops': troops_to_attack, 'result': result})
                                break  # Only one attack per tile per turn
        
        return actions
    
    def evaluate_tile_value(self, tile: Dict) -> int:
        """Evaluate the strategic value of a tile"""
        value = 0
        
        # Resource value
        for resource, amount in tile['resources'].items():
            value += amount
        
        # Structure value
        structure_values = {
            'castle': 100,
            'barracks': 50,
            'tower': 40,
            'farm': 30,
            'mine': 60,
            'temple': 70
        }
        
        for structure in tile['structures']:
            value += structure_values.get(structure, 10)
        
        # Troop value
        for troop_type, quantity in tile['troops'].items():
            value += quantity * 5
        
        return value
    
    def set_personality(self, personality: str):
        """Set AI personality"""
        valid_personalities = ['aggressive', 'defensive', 'economic', 'balanced']
        if personality in valid_personalities:
            self.personality = personality
        else:
            logging.warning(f"Invalid personality: {personality}. Using 'balanced'")
            self.personality = 'balanced'
