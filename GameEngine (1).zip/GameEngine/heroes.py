import random
import json
from typing import Dict, List, Any

class HeroManager:
    def __init__(self):
        self.hero_types = {
            'warrior_hero': {
                'name': 'Warrior Hero',
                'cost': {'gold': 500, 'food': 100},
                'stats': {'attack': 50, 'defense': 40, 'health': 100, 'movement': 2},
                'abilities': ['charge', 'rally_troops'],
                'description': 'A mighty warrior who leads from the front'
            },
            'archer_hero': {
                'name': 'Archer Hero',
                'cost': {'gold': 400, 'wood': 200},
                'stats': {'attack': 40, 'defense': 30, 'health': 80, 'movement': 3},
                'abilities': ['precise_shot', 'rain_of_arrows'],
                'description': 'A skilled archer with deadly accuracy'
            },
            'mage_hero': {
                'name': 'Mage Hero',
                'cost': {'gold': 600, 'stone': 150},
                'stats': {'attack': 60, 'defense': 25, 'health': 70, 'movement': 2},
                'abilities': ['fireball', 'heal', 'teleport'],
                'description': 'A powerful spellcaster with magical abilities'
            },
            'scout_hero': {
                'name': 'Scout Hero',
                'cost': {'gold': 300, 'food': 50},
                'stats': {'attack': 25, 'defense': 20, 'health': 60, 'movement': 4},
                'abilities': ['stealth', 'reveal_map', 'quick_escape'],
                'description': 'A swift scout with excellent reconnaissance skills'
            }
        }
    
    def get_available_heroes(self) -> Dict:
        """Get all available hero types"""
        return self.hero_types
    
    def get_player_heroes(self, player_id: str) -> List[Dict]:
        """Get heroes owned by a specific player"""
        # This would typically load from game state
        # For now, return empty list - will be populated when heroes are recruited
        return []
    
    def recruit_hero(self, player_id: str, hero_type: str) -> Dict:
        """Recruit a new hero"""
        if hero_type not in self.hero_types:
            return {'success': False, 'message': 'Invalid hero type'}
        
        hero_template = self.hero_types[hero_type]
        
        # Create a new hero instance
        new_hero = {
            'id': f"{player_id}_{hero_type}_{random.randint(1000, 9999)}",
            'type': hero_type,
            'name': hero_template['name'],
            'owner': player_id,
            'stats': hero_template['stats'].copy(),
            'abilities': hero_template['abilities'].copy(),
            'level': 1,
            'experience': 0,
            'location': None,  # Will be set when deployed
            'status': 'available',  # available, deployed, injured, dead
            'equipment': [],
            'created_at': None  # Would be set to current game day
        }
        
        return {
            'success': True,
            'message': f'{hero_template["name"]} recruited successfully',
            'hero': new_hero,
            'cost': hero_template['cost']
        }
    
    def deploy_hero(self, hero_id: str, x: int, y: int) -> Dict:
        """Deploy a hero to a specific tile"""
        # This would check if the tile is owned by the player
        # and move the hero there
        return {
            'success': True,
            'message': f'Hero deployed to ({x}, {y})'
        }
    
    def use_hero_ability(self, hero_id: str, ability: str, target_x: int = None, target_y: int = None) -> Dict:
        """Use a hero's special ability"""
        ability_effects = {
            'charge': {'effect': 'damage_boost', 'duration': 1, 'power': 2.0},
            'rally_troops': {'effect': 'troop_morale_boost', 'duration': 3, 'power': 1.5},
            'precise_shot': {'effect': 'single_target_damage', 'power': 3.0},
            'rain_of_arrows': {'effect': 'area_damage', 'radius': 2, 'power': 1.5},
            'fireball': {'effect': 'area_damage', 'radius': 1, 'power': 4.0},
            'heal': {'effect': 'restore_health', 'power': 50},
            'teleport': {'effect': 'instant_movement', 'range': 5},
            'stealth': {'effect': 'invisibility', 'duration': 2},
            'reveal_map': {'effect': 'scout_area', 'radius': 3},
            'quick_escape': {'effect': 'retreat', 'success_chance': 0.9}
        }
        
        if ability not in ability_effects:
            return {'success': False, 'message': 'Invalid ability'}
        
        effect = ability_effects[ability]
        
        return {
            'success': True,
            'message': f'Used {ability}',
            'effect': effect
        }
    
    def level_up_hero(self, hero_id: str) -> Dict:
        """Level up a hero"""
        # Increase stats based on hero type and level
        stat_increases = {
            'warrior_hero': {'attack': 5, 'defense': 4, 'health': 10},
            'archer_hero': {'attack': 4, 'defense': 3, 'health': 8},
            'mage_hero': {'attack': 6, 'defense': 2, 'health': 7},
            'scout_hero': {'attack': 3, 'defense': 2, 'health': 6, 'movement': 1}
        }
        
        return {
            'success': True,
            'message': 'Hero leveled up!',
            'stat_increases': stat_increases
        }
    
    def get_hero_by_id(self, hero_id: str) -> Dict:
        """Get hero details by ID"""
        # This would search through player heroes in game state
        return {'error': 'Hero not found'}
