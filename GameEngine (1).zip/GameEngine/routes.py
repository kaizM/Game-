from flask import render_template, jsonify, request, session
from app import app
import json
import os
import logging
from game_logic import GameEngine
from ai_logic import AIPlayer
from heroes import HeroManager

# Initialize game components
game_engine = GameEngine()
ai_player = AIPlayer()
hero_manager = HeroManager()

@app.route('/')
def index():
    """Main game landing page"""
    return render_template('index.html')

@app.route('/game')
def game():
    """Main game interface"""
    player_id = session.get('player_id', 'player1')
    game_state = game_engine.get_game_state()
    return render_template('game.html', player_id=player_id, game_state=game_state)

@app.route('/api/game-state')
def get_game_state():
    """Get current game state as JSON"""
    try:
        game_state = game_engine.get_game_state()
        return jsonify(game_state)
    except Exception as e:
        logging.error(f"Error getting game state: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/player/<player_id>/stats')
def get_player_stats(player_id):
    """Get specific player statistics"""
    try:
        stats = game_engine.get_player_stats(player_id)
        return jsonify(stats)
    except Exception as e:
        logging.error(f"Error getting player stats: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/tile/<int:x>/<int:y>')
def get_tile_info(x, y):
    """Get information about a specific tile"""
    try:
        tile_info = game_engine.get_tile_info(x, y)
        return jsonify(tile_info)
    except Exception as e:
        logging.error(f"Error getting tile info: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/build', methods=['POST'])
def build_structure():
    """Build a structure on a tile"""
    try:
        data = request.get_json()
        player_id = session.get('player_id', data.get('player_id', 'player1'))
        x = data.get('x')
        y = data.get('y')
        structure_type = data.get('structure_type')
        
        result = game_engine.build_structure(player_id, x, y, structure_type)
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error building structure: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/train-troops', methods=['POST'])
def train_troops():
    """Train troops at a structure"""
    try:
        data = request.get_json()
        player_id = session.get('player_id', data.get('player_id', 'player1'))
        x = data.get('x')
        y = data.get('y')
        troop_type = data.get('troop_type')
        quantity = data.get('quantity', 1)
        
        result = game_engine.train_troops(player_id, x, y, troop_type, quantity)
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error training troops: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/move-army', methods=['POST'])
def move_army():
    """Move army from one tile to another"""
    try:
        data = request.get_json()
        player_id = session.get('player_id', data.get('player_id', 'player1'))
        from_x = data.get('from_x')
        from_y = data.get('from_y')
        to_x = data.get('to_x')
        to_y = data.get('to_y')
        troops = data.get('troops', {})
        
        result = game_engine.move_army(player_id, from_x, from_y, to_x, to_y, troops)
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error moving army: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/scout', methods=['POST'])
def scout_tile():
    """Scout a tile to reveal information"""
    try:
        data = request.get_json()
        player_id = session.get('player_id', data.get('player_id', 'player1'))
        x = data.get('x')
        y = data.get('y')
        
        result = game_engine.scout_tile(player_id, x, y)
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error scouting tile: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/attack', methods=['POST'])
def attack_tile():
    """Attack a tile"""
    try:
        data = request.get_json()
        player_id = session.get('player_id', data.get('player_id', 'player1'))
        from_x = data.get('from_x')
        from_y = data.get('from_y')
        to_x = data.get('to_x')
        to_y = data.get('to_y')
        troops = data.get('troops', {})
        
        result = game_engine.attack_tile(player_id, from_x, from_y, to_x, to_y, troops)
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error attacking tile: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/end-turn', methods=['POST'])
def end_turn():
    """End current player's turn"""
    try:
        player_id = session.get('player_id', 'player1')
        result = game_engine.end_turn(player_id)
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error ending turn: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/heroes')
def get_heroes():
    """Get available heroes"""
    try:
        player_id = session.get('player_id', 'player1')
        heroes = hero_manager.get_player_heroes(player_id)
        return jsonify(heroes)
    except Exception as e:
        logging.error(f"Error getting heroes: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/recruit-hero', methods=['POST'])
def recruit_hero():
    """Recruit a new hero"""
    try:
        data = request.get_json()
        player_id = session.get('player_id', data.get('player_id', 'player1'))
        hero_type = data.get('hero_type')
        
        result = hero_manager.recruit_hero(player_id, hero_type)
        return jsonify(result)
    except Exception as e:
        logging.error(f"Error recruiting hero: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/set-player/<player_id>')
def set_player(player_id):
    """Set the current player session"""
    session['player_id'] = player_id
    return jsonify({'message': f'Player set to {player_id}'})
